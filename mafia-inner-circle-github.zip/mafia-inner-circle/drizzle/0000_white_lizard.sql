CREATE TABLE `members` (
	`account` text PRIMARY KEY NOT NULL,
	`code` text NOT NULL,
	`updated` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `rooms` (
	`code` text PRIMARY KEY NOT NULL,
	`state` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`mode` text NOT NULL,
	`phase` text NOT NULL,
	`seats` integer NOT NULL,
	`count` integer NOT NULL,
	`updated` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_rooms_matchmaking` ON `rooms` (`mode`,`phase`,`seats`,`updated`);