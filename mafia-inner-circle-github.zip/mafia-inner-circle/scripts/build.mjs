import { cp, mkdir, rm, writeFile } from "node:fs/promises";
import { build } from "esbuild";
await rm("dist", { recursive: true, force: true });
await mkdir("dist/client", { recursive: true });
await mkdir("dist/server", { recursive: true });
await mkdir("dist/.openai", { recursive: true });
await Promise.all([
  cp("src/assets", "dist/client/assets", { recursive: true }),
  cp("src/index.html", "dist/client/index.html"),
  cp("src/styles.css", "dist/client/styles.css"),
  cp(".openai/hosting.json", "dist/.openai/hosting.json"),
  cp("drizzle", "dist/.openai/drizzle", { recursive: true }),
]);
await build({
  entryPoints: ["src/app.js"],
  outfile: "dist/client/app.js",
  bundle: true,
  format: "esm",
  target: "es2022",
  minify: true,
});
await build({
  entryPoints: ["server/worker.js"],
  outfile: "dist/server/index.js",
  bundle: true,
  format: "esm",
  platform: "browser",
  target: "es2022",
});
await writeFile(
  "dist/server/wrangler.json",
  JSON.stringify({
    name: "mafia-inner-circle",
    main: "index.js",
    compatibility_date: "2026-09-01",
    assets: { directory: "../client", binding: "ASSETS" },
    d1_databases: [
      { binding: "DB", database_name: "mafia-game", database_id: "local" },
    ],
  }),
);
console.log("Built authoritative game server and mobile client.");
