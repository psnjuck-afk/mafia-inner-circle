import http from "node:http";
import { DatabaseSync } from "node:sqlite";
import { readFile, mkdir, readdir } from "node:fs/promises";
import path from "node:path";
import worker from "../server/worker.js";
await mkdir(".runtime", { recursive: true });
const db = new DatabaseSync(".runtime/game.sqlite");
db.exec("CREATE TABLE IF NOT EXISTS _local_migrations (name TEXT PRIMARY KEY)");
for (const name of (await readdir("drizzle"))
  .filter((x) => x.endsWith(".sql"))
  .sort())
  if (
    !db.prepare("SELECT name FROM _local_migrations WHERE name=?").get(name)
  ) {
    db.exec(await readFile("drizzle/" + name, "utf8"));
    db.prepare("INSERT INTO _local_migrations(name) VALUES (?)").run(name);
  }
const DB = {
  prepare(sql) {
    return {
      bind(...args) {
        return {
          async first() {
            return db.prepare(sql).get(...args) || null;
          },
          async all() {
            return { results: db.prepare(sql).all(...args) };
          },
          async run() {
            return {
              meta: { changes: Number(db.prepare(sql).run(...args).changes) },
            };
          },
        };
      },
    };
  },
};
const types = {
  ".html": "text/html",
  ".js": "text/javascript",
  ".css": "text/css",
  ".svg": "image/svg+xml",
  ".webp": "image/webp",
};
const ASSETS = {
  async fetch(req) {
    let p = new URL(req.url).pathname;
    if (p === "/") p = "/index.html";
    const file = path.resolve("dist/client", "." + p);
    if (!file.startsWith(path.resolve("dist/client") + "/"))
      return new Response("Forbidden", { status: 403 });
    try {
      return new Response(await readFile(file), {
        headers: {
          "content-type":
            types[path.extname(file)] || "application/octet-stream",
        },
      });
    } catch {
      return new Response("Not found", { status: 404 });
    }
  },
};
const env = {
  DB,
  ASSETS,
  AUTH_MODE: process.env.AUTH_MODE,
  TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN,
  OPENAI_API_KEY: process.env.OPENAI_API_KEY,
  LIVEKIT_URL: process.env.LIVEKIT_URL,
  LIVEKIT_API_KEY: process.env.LIVEKIT_API_KEY,
  LIVEKIT_API_SECRET: process.env.LIVEKIT_API_SECRET,
};
http
  .createServer(async (req, res) => {
    try {
      let chunks = [];
      for await (const chunk of req) chunks.push(chunk);
      const headers = new Headers(req.headers);
      const cookies = req.headers.cookie || "";
      const user =
        req.headers["x-local-player"] ||
        cookies.match(/dev_player=([a-zA-Z0-9_-]+)/)?.[1] ||
        "local-owner";
      headers.set("oai-authenticated-user-id", user);
      const request = new Request("http://127.0.0.1:4173" + req.url, {
        method: req.method,
        headers,
        body: ["GET", "HEAD"].includes(req.method)
          ? undefined
          : Buffer.concat(chunks),
      });
      const result = await worker.fetch(request, env, {
        waitUntil(p) {
          p.catch(console.error);
        },
      });
      res.writeHead(result.status, Object.fromEntries(result.headers));
      res.end(Buffer.from(await result.arrayBuffer()));
    } catch (e) {
      res.writeHead(500);
      res.end(e.message);
    }
  })
  .listen(4173, "0.0.0.0", () =>
    console.log("Mafia preview http://127.0.0.1:4173"),
  );
