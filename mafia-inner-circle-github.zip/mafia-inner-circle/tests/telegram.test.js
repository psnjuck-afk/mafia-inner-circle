import test from "node:test";
import assert from "node:assert/strict";
import { telegramIdentity } from "../server/telegram.js";
import { identity } from "../server/identity.js";
import { botToken, signedData } from "./telegram-fixture.js";
import { avatar, nameField } from "../src/profile.js";

test("verified Telegram profile uses a stable 52-bit-safe ID and first name", async () => {
  const data = await telegramIdentity(signedData(), botToken);
  assert.equal(data.id, "telegram:1234567890123");
  assert.equal(data.profile.name, "Михаил");
  assert.equal(data.profile.photoUrl, "https://t.me/i/userpic/320/test.jpg");
  const changed = await telegramIdentity(signedData({ id: 1234567890123, first_name: "Миша", last_name: "Иванов" }), botToken);
  assert.equal(changed.id, data.id);
  assert.equal(changed.profile.name, "Миша");
  assert.equal(changed.profile.photoUrl, null);
});
test("encoded Cyrillic, plus signs and optional signature fields are verified unchanged", async () => {
  const data = await telegramIdentity(signedData({ id: 2, first_name: "Миша + Даша 👀", photo_url: "https://t.me/i/userpic/test.svg?x=a+b&y=2" }, { fields: { signature: "telegram-signature-field" } }), botToken);
  assert.equal(data.profile.name, "Миша + Даша 👀");
  assert(data.profile.photoUrl.includes("x=a+b&y=2"));
});
test("tampered names, photos, hashes, duplicate parameters and a different bot are rejected", async () => {
  const original = signedData();
  const altered = new URLSearchParams(original);
  altered.set("user", JSON.stringify({ id: 1234567890123, first_name: "Подмена", photo_url: "https://attacker.test/photo" }));
  for (const raw of [altered.toString(), original + "&user={}", original.replace(/hash=[^&]+/, "hash=00"), signedData(undefined, { botToken: "another-bot" })]) {
    await assert.rejects(telegramIdentity(raw, botToken), { status: 401 });
  }
});
test("expired and future launch data fail while a normal long game remains authenticated", async () => {
  const now = Math.floor(Date.now() / 1000);
  await assert.rejects(telegramIdentity(signedData(undefined, { authDate: now - 28801 }), botToken), { status: 401 });
  await assert.rejects(telegramIdentity(signedData(undefined, { authDate: now + 90 }), botToken), { status: 401 });
  assert(await telegramIdentity(signedData(undefined, { authDate: now - 7200 }), botToken));
});
test("invalid users and missing bot configuration fail closed", async () => {
  for (const user of [null, { id: "123", first_name: "Миша" }, { id: 1, first_name: {} }, { id: -1, first_name: "Миша" }])
    await assert.rejects(telegramIdentity(signedData(user), botToken), { status: 401 });
  await assert.rejects(telegramIdentity(signedData(), ""), { status: 503 });
});
test("standalone Telegram mode ignores forged Sites headers and unsigned query profiles", async () => {
  const req = new Request("https://game.test/api/session?user=123", { headers: { "oai-authenticated-user-id": "123", "oai-authenticated-user-full-name": "Mikhail" } });
  assert.equal(await identity(req, { AUTH_MODE: "telegram", TELEGRAM_BOT_TOKEN: botToken }), null);
  const forged = new Request(req, { headers: { ...Object.fromEntries(req.headers), authorization: "tma invalid" } });
  await assert.rejects(identity(forged, { TELEGRAM_BOT_TOKEN: botToken }), { status: 401 });
});
test("unsafe photo URLs are removed and HTML is escaped in every profile surface", async () => {
  const data = await telegramIdentity(signedData({ id: 1, first_name: '<img onerror="alert(1)">', photo_url: "javascript:alert(1)" }), botToken);
  assert.equal(data.profile.photoUrl, null);
  const rendered = nameField({ name: data.profile.name, profile: data.profile });
  assert(!rendered.includes('<img onerror'));
  assert(!rendered.includes('id="nickname"'));
  assert(!avatar({ name: "Миша", photoUrl: "data:image/svg+xml,evil" }).includes("<img"));
});
