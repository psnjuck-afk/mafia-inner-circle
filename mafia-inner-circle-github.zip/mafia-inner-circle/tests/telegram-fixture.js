import { createHmac } from "node:crypto";
export const botToken = "123456789:test-only-token-not-valid";
export function signedData(user = { id: 1234567890123, first_name: "Михаил", photo_url: "https://t.me/i/userpic/320/test.jpg" }, options = {}) {
  const params = new URLSearchParams({ query_id: "test-query", auth_date: String(options.authDate ?? Math.floor(Date.now() / 1000)), user: JSON.stringify(user), ...options.fields });
  const data = [...params].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, value]) => `${key}=${value}`).join("\n");
  const secret = createHmac("sha256", "WebAppData").update(options.botToken || botToken).digest();
  params.set("hash", createHmac("sha256", secret).update(data).digest("hex"));
  return params.toString();
}
