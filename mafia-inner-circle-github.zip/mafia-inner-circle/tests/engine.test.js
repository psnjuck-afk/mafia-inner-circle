import test from "node:test";
import assert from "node:assert/strict";
import {
  createGame,
  joinGame,
  command,
  tick,
  view,
  composition,
  voiceAccess,
  targets,
  checkWin,
} from "../server/engine.js";
const T = 1000000;
function fixture(n = 6) {
  const g = createGame({
    code: "ABC234",
    ownerId: "u0",
    name: "Ноль",
    seats: n,
    mode: "private",
    now: T,
    seed: 17,
  });
  for (let i = 1; i < n; i++) joinGame(g, "u" + i, "Игрок " + i, T);
  g.players.forEach((p) => (p.ready = true));
  command(g, "u0", { type: "start" }, T);
  const deck = Object.entries(composition(n)).flatMap(([r, c]) =>
    Array(c).fill(r),
  );
  g.players.forEach((p, i) => {
    p.role = deck[i];
    p.lastSeen = T + 1000000;
  });
  return g;
}
function night(g) {
  g.phase = "night";
  g.day = 1;
  g.deadline = T + 60000;
  g.nightIds = g.players.map((p) => p.id);
  g.botAt = Infinity;
  return g;
}
function vote(g, runoff = false) {
  g.phase = "vote";
  g.day = 1;
  g.deadline = T + 30000;
  g.voteIds = g.players.filter((p) => p.alive).map((p) => p.id);
  g.votes = {};
  g.botAt = Infinity;
  g.runoff = runoff;
  g.nominees = g.voteIds;
  return g;
}
const act = (g, p, type, extra = {}) =>
  command(g, p.accountId, { type, ...extra }, T + 1000);
for (const n of [6, 7, 8, 9, 10])
  test(`composition ${n} preserves four roles`, () => {
    const c = composition(n);
    assert.equal(
      Object.values(c).reduce((a, b) => a + b),
      n,
    );
    assert.equal(c.doctor, 1);
    assert.equal(c.detective, 1);
    assert.equal(c.mafia, n < 8 ? 1 : 2);
    const g = fixture(n);
    assert.equal(g.players.filter((p) => p.role === "mafia").length, c.mafia);
  });
test("unconfirmed night means no random kill", () => {
  const g = night(fixture());
  tick(g, T + 60000);
  assert.equal(g.players.filter((p) => p.alive).length, 6);
  assert.equal(g.phase, "dawn");
});
test("doctor saves the target", () => {
  const g = night(fixture()),
    m = g.players[0],
    d = g.players[2],
    v = g.players[3];
  act(g, m, "night", { target: v.id });
  act(g, d, "night", { target: v.id });
  tick(g, T + 60000);
  assert.equal(v.alive, true);
  assert.equal(g.history.at(-1).saved, true);
});
test("doctor acts even when killed the same night", () => {
  const g = night(fixture()),
    m = g.players[0],
    d = g.players[2],
    v = g.players[3];
  act(g, m, "night", { target: d.id });
  act(g, d, "night", { target: v.id });
  tick(g, T + 60000);
  assert.equal(d.alive, false);
  assert.equal(d.lastHeal, v.id);
});
test("self healing is once per game; consecutive target disallowed", () => {
  const g = night(fixture()),
    d = g.players[2];
  act(g, d, "night", { target: d.id });
  tick(g, T + 60000);
  night(g);
  assert(!targets(g, d).includes(d.id));
  assert.throws(() => act(g, d, "night", { target: d.id }));
  d.lastHeal = g.players[3].id;
  assert(!targets(g, d).includes(g.players[3].id));
});
test("two mafia disagree: nobody dies", () => {
  const g = night(fixture(8));
  act(g, g.players[0], "night", { target: g.players[4].id });
  act(g, g.players[1], "night", { target: g.players[5].id });
  tick(g, T + 60000);
  assert.equal(g.players.filter((p) => p.alive).length, 8);
});
test("two mafia agree: exactly one victim", () => {
  const g = night(fixture(8));
  for (const m of g.players.slice(0, 2))
    act(g, m, "night", { target: g.players[4].id });
  tick(g, T + 60000);
  assert.equal(g.players.filter((p) => p.alive).length, 7);
});
test("one missing mafia confirmation is a missed kill", () => {
  const g = night(fixture(8));
  act(g, g.players[0], "night", { target: g.players[4].id });
  tick(g, T + 60000);
  assert.equal(g.players.filter((p) => p.alive).length, 8);
});
test("confirmed night never ends early", () => {
  const g = night(fixture());
  for (const p of g.players.filter((p) => p.role !== "civilian"))
    act(g, p, "night", { target: "skip" });
  tick(g, T + 59000);
  assert.equal(g.phase, "night");
});
test("detective sees affiliation; only their own checks are visible", () => {
  const g = night(fixture()),
    d = g.players[1];
  act(g, d, "night", { target: g.players[0].id });
  tick(g, T + 60000);
  assert.equal(view(g, d.accountId, T + 60000).me.checks[0].mafia, true);
  const v = view(g, "u3", T + 60000);
  assert.deepEqual(v.me.checks, []);
  assert(!("check" in v.history[0]));
  assert(!("heal" in v.history[0]));
  assert(v.players.every((p) => p.role === undefined));
});
test("mafia voice room is inaccessible to town and ghosts", () => {
  const g = night(fixture(8));
  assert.equal(voiceAccess(g, g.players[0]).channel, "mafia");
  assert.equal(voiceAccess(g, g.players[4]).rooms.length, 0);
  g.players[1].alive = false;
  const v = voiceAccess(g, g.players[1]);
  assert.equal(v.channel, "ghost");
  assert(v.rooms.every((r) => !r.name.endsWith("-mafia")));
});
test("only current accepted speaker can publish during day", () => {
  const g = fixture();
  g.phase = "turn";
  g.speakerId = g.players[3].id;
  g.turnState = "offer";
  assert.equal(voiceAccess(g, g.players[3]).publish, false);
  g.turnState = "speaking";
  assert.equal(voiceAccess(g, g.players[3]).publish, true);
  assert.equal(voiceAccess(g, g.players[2]).publish, false);
});
test("accepting the floor grants full time; no audio event can end it", () => {
  const g = fixture();
  g.phase = "turn";
  g.turnKind = "main";
  g.turnState = "offer";
  g.speakerId = g.players[3].id;
  g.queue = g.players.map((p) => p.id);
  g.turnIndex = 3;
  g.deadline = T + 10000;
  act(g, g.players[3], "speak");
  assert.equal(g.deadline, T + 41000);
  tick(g, T + 30000);
  assert.equal(g.speakerId, g.players[3].id);
  assert.equal(g.turnState, "speaking");
});
test("vote ties produce defense and only one runoff", () => {
  const g = vote(fixture());
  const [a, b] = g.players.map((p) => p.id);
  g.votes = Object.fromEntries(g.players.map((p, i) => [p.id, i % 2 ? a : b]));
  tick(g, T + 1000);
  assert.equal(g.phase, "turn");
  assert.equal(g.turnKind, "defense");
  vote(g, true);
  g.votes = Object.fromEntries(g.players.map((p, i) => [p.id, i % 2 ? a : b]));
  tick(g, T + 2000);
  assert.equal(g.phase, "result");
  assert.equal(g.players.filter((p) => p.alive).length, 6);
});
test("skip tied for first place prevents exclusion", () => {
  const g = vote(fixture());
  g.votes = Object.fromEntries(
    g.players.map((p, i) => [p.id, i < 3 ? "skip" : g.players[2].id]),
  );
  tick(g, T + 1000);
  assert.equal(g.phase, "result");
  assert(g.players.every((p) => p.alive));
});
test("missing votes count as skip", () => {
  const g = vote(fixture());
  g.votes[g.players[0].id] = g.players[3].id;
  tick(g, T + 30000);
  assert.equal(g.lastVote.counts.skip, 5);
  assert(g.players.every((p) => p.alive));
});
test("vote is immutable; dead player cannot act", () => {
  const g = vote(fixture());
  act(g, g.players[0], "vote", { target: g.players[3].id });
  assert.throws(() => act(g, g.players[0], "vote", { target: "skip" }));
  g.players[2].alive = false;
  assert.throws(() => act(g, g.players[2], "vote", { target: "skip" }));
});
test("night and vote reject self / invalid targets", () => {
  const g = night(fixture());
  assert.throws(() =>
    act(g, g.players[0], "night", { target: g.players[0].id }),
  );
  assert.throws(() =>
    act(g, g.players[1], "night", { target: g.players[1].id }),
  );
  assert.throws(() =>
    act(g, g.players[3], "night", { target: g.players[0].id }),
  );
  vote(g);
  assert.throws(() =>
    act(g, g.players[0], "vote", { target: g.players[0].id }),
  );
});
test("stale phase cannot submit actions into the next phase", () => {
  const g = night(fixture());
  assert.throws(() =>
    command(
      g,
      "u0",
      { type: "night", target: "skip", phaseSeq: g.phaseSeq - 1 },
      T + 1000,
    ),
  );
});
test("mafia parity and eliminated mafia stop immediately", () => {
  let g = fixture();
  g.players.slice(2).forEach((p) => (p.alive = false));
  assert(checkWin(g, T));
  assert.equal(g.winner, "mafia");
  g = fixture();
  g.players[0].alive = false;
  assert(checkWin(g, T));
  assert.equal(g.winner, "town");
});
test("role timeout returns the whole room to lobby", () => {
  const g = fixture();
  tick(g, T + 30000);
  assert.equal(g.phase, "lobby");
  assert(g.players.every((p) => p.role === undefined));
});
test("full training reaches a computed ending and supports rematch", () => {
  const g = createGame({
    code: "DEF234",
    ownerId: "u",
    name: "Вы",
    seats: 8,
    mode: "training",
    now: T,
    seed: 19,
  });
  command(g, "u", { type: "ready" }, T);
  command(g, "u", { type: "start" }, T);
  command(g, "u", { type: "role_ready" }, T);
  let now = T;
  for (let i = 0; i < 350 && g.phase !== "gameover"; i++) {
    now += 1000;
    const me = g.players[0];
    if (me.needsPresence) command(g, "u", { type: "presence" }, now);
    if (g.phase === "turn" && g.speakerId === me.id)
      command(g, "u", { type: "pass" }, now);
    else if (g.phase === "vote" && me.alive && !g.votes[me.id])
      command(g, "u", { type: "vote", target: "skip" }, now);
    else command(g, "u", { type: "training_next" }, now);
  }
  assert.equal(g.phase, "gameover");
  assert(g.winner);
  assert(g.history.some((e) => e.type === "night"));
  command(g, "u", { type: "postgame" }, now);
  command(g, "u", { type: "ready" }, now);
  command(g, "u", { type: "start" }, now);
  assert.equal(g.phase, "role");
  assert.equal(g.match, 2);
  assert(g.players.every((p) => p.alive));
});
test("voice outage pauses and resumes deadlines without losing time", () => {
  const g = night(fixture());
  const oldDeadline = g.deadline;
  for (const p of g.players.slice(0, 3))
    command(g, p.accountId, { type: "voice_error" }, T + 5000);
  assert(g.pausedUntil);
  tick(g, T + 40000);
  assert.equal(g.phase, "night");
  command(g, "u0", { type: "voice_ok" }, T + 45000);
  assert.equal(g.pausedUntil, null);
  assert.equal(g.deadline, oldDeadline + 40000);
});
test("unresolved voice outage ends without winner", () => {
  const g = night(fixture());
  for (const p of g.players.slice(0, 3))
    command(g, p.accountId, { type: "voice_error" }, T + 5000);
  tick(g, T + 65000);
  assert.equal(g.winner, "aborted");
});
test("returning after the grace period does not revive a player", () => {
  const g = night(fixture());
  g.players[3].lastSeen = T - 5000;
  tick(g, T + 59000);
  assert.equal(g.players[3].pendingRemoval, true);
  g.players[3].lastSeen = T + 59000;
  tick(g, T + 60000);
  assert.equal(g.players[3].alive, false);
});
