import test from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { readFileSync, readdirSync } from "node:fs";
import worker from "../server/worker.js";
import { createGame } from "../server/engine.js";
import { insert, remember, load } from "../server/store.js";
import { botToken, signedData } from "./telegram-fixture.js";
function environment() {
  const db = new DatabaseSync(":memory:");
  for (const f of readdirSync("drizzle")
    .filter((x) => x.endsWith(".sql"))
    .sort())
    db.exec(readFileSync("drizzle/" + f, "utf8"));
  const DB = {
    prepare(sql) {
      return {
        bind(...args) {
          return {
            async first() {
              return db.prepare(sql).get(...args) || null;
            },
            async all() {
              return { results: db.prepare(sql).all(...args) };
            },
            async run() {
              return {
                meta: { changes: Number(db.prepare(sql).run(...args).changes) },
              };
            },
          };
        },
      };
    },
  };
  return { DB, ASSETS: { fetch: () => new Response("asset") } };
}
async function request(env, id, path, data, extraHeaders = {}) {
  const headers = { "content-type": "application/json", ...extraHeaders };
  if (id) headers["oai-authenticated-user-id"] = id;
  const r = await worker.fetch(
    new Request("https://game.test" + path, {
      method: data ? "POST" : "GET",
      headers,
      body: data ? JSON.stringify(data) : undefined,
    }),
    env,
    { waitUntil() {} },
  );
  return { status: r.status, data: await r.json() };
}
test("unauthenticated API is rejected", async () => {
  const r = await request(environment(), null, "/api/session");
  assert.equal(r.status, 401);
});
test("Telegram profiles reach all players; body spoofing is ignored and reconnect keeps the seat", async () => {
  const env = { ...environment(), AUTH_MODE: "telegram", TELEGRAM_BOT_TOKEN: botToken };
  const auth = { authorization: "tma " + signedData() };
  const session = await request(env, null, "/api/session", undefined, auth);
  assert.equal(session.data.profile.name, "Михаил");
  const created = await request(env, null, "/api/rooms", { seats: 6, name: "Подмена", photoUrl: "https://evil.test" }, auth);
  assert.equal(created.status, 200);
  assert.equal(created.data.me.name, "Михаил");
  assert.equal(created.data.players[0].photoUrl, "https://t.me/i/userpic/320/test.jpg");
  assert.equal(created.data.players[0].accountId, undefined);
  const second = { authorization: "tma " + signedData({ id: 2, first_name: "Анна" }) };
  const joined = await request(env, null, "/api/join", { code: created.data.code, name: "Подмена" }, second);
  assert.equal(joined.data.me.name, "Анна");
  assert.equal(joined.data.players[0].photoUrl, created.data.me.photoUrl);
  assert.equal(joined.data.players[1].photoUrl, null);
  const changed = { authorization: "tma " + signedData({ id: 1234567890123, first_name: "Миша" }) };
  const resumed = await request(env, null, `/api/rooms/${created.data.code}`, undefined, changed);
  assert.equal(resumed.data.me.id, created.data.me.id);
  assert.equal(resumed.data.me.name, "Миша");
  assert.equal(resumed.data.me.photoUrl, null);
  assert.equal(resumed.data.players.length, 2);
  const returned = await request(env, null, "/api/session", undefined, changed);
  assert.equal(returned.data.room, created.data.code);
  const observing = await request(env, null, `/api/rooms/${created.data.code}`, undefined, second);
  assert.equal(observing.data.players[0].name, "Миша");
});
test("Telegram matchmaking also uses the signed profile", async () => {
  const env = { ...environment(), AUTH_MODE: "telegram", TELEGRAM_BOT_TOKEN: botToken };
  const auth = { authorization: "tma " + signedData() };
  const first = await request(env, null, "/api/rooms", { seats: 6, mode: "quick" }, auth);
  const secondAuth = { authorization: "tma " + signedData({ id: 9, first_name: "Антон" }) };
  const next = await request(env, null, "/api/rooms", { seats: 6, mode: "quick", name: "Fake" }, secondAuth);
  assert.equal(first.data.code, next.data.code);
  assert.equal(next.data.me.name, "Антон");
  assert.equal(next.data.players[0].name, "Михаил");
});
test("Telegram API returns clear auth failures and retains Sites demo compatibility", async () => {
  const env = { ...environment(), AUTH_MODE: "telegram", TELEGRAM_BOT_TOKEN: botToken };
  assert.equal((await request(env, "forged-platform-id", "/api/session")).status, 401);
  assert.equal((await request(env, null, "/api/session", undefined, { authorization: "tma user={}" })).status, 401);
  assert.equal((await request({ ...env, TELEGRAM_BOT_TOKEN: "" }, null, "/api/session", undefined, { authorization: "tma " + signedData() })).status, 503);
  const demo = await request(environment(), "owner", "/api/session", undefined, { "oai-authenticated-user-full-name": "Mikhail" });
  assert.equal(demo.data.profile.name, "Mikhail");
  assert.equal(demo.data.profile.source, "sites");
});
test("training and phase skipping are disabled in the public API", async () => {
  const env = environment();
  assert.equal(
    (await request(env, "u", "/api/rooms", { mode: "training", seats: 6 }))
      .status,
    410,
  );
  const { data: g } = await request(env, "u", "/api/rooms", { seats: 6 });
  assert.equal(g.mode, "private");
  assert.equal(g.players.length, 1);
  assert.equal(
    (
      await request(env, "u", `/api/rooms/${g.code}/action`, {
        type: "training_next",
      })
    ).status,
    400,
  );
});
test("old training sessions close and free the player's membership", async () => {
  const env = environment(),
    now = Date.now();
  const g = createGame({
    code: "ABC234",
    ownerId: "u",
    name: "Player",
    mode: "training",
    seats: 6,
    now,
  });
  await insert(env.DB, g, now);
  await remember(env.DB, "u", g.code, now);
  assert.equal((await request(env, "u", `/api/rooms/${g.code}`)).status, 410);
  const session = await request(env, "u", "/api/session");
  assert.equal(session.data.room, null);
  assert.equal(
    (await request(env, "u", "/api/rooms", { mode: "private", seats: 8 }))
      .status,
    200,
  );
});
test("without LiveKit credentials the server refuses readiness and start", async () => {
  const env = environment();
  const { data: g } = await request(env, "u", "/api/rooms", {
    mode: "private",
    seats: 6,
  });
  for (const type of ["ready", "start"])
    assert.equal(
      (await request(env, "u", `/api/rooms/${g.code}/action`, { type })).status,
      503,
    );
  assert.equal(
    (await request(env, "u", "/api/voice/status")).data.connected,
    false,
  );
});
function voiceEnvironment(t) {
  const env = {
    ...environment(),
    LIVEKIT_URL: "wss://unit-test.invalid",
    LIVEKIT_API_KEY: crypto.randomUUID(),
    LIVEKIT_API_SECRET: "unit-test-secret",
  };
  t.mock.method(
    globalThis,
    "fetch",
    async () => new Response("{}", { status: 200 }),
  );
  return env;
}
test("invalid LiveKit credentials do not allow game start", async (t) => {
  const env = voiceEnvironment(t);
  t.mock.method(
    globalThis,
    "fetch",
    async () => new Response("denied", { status: 401 }),
  );
  const { data: g } = await request(env, "u", "/api/rooms", { seats: 6 });
  assert.equal(
    (await request(env, "u", `/api/rooms/${g.code}/action`, { type: "ready" }))
      .status,
    503,
  );
  assert.equal(
    (await request(env, "u", `/api/rooms/${g.code}`)).data.players[0].ready,
    false,
  );
});
test("separate accounts join one room; strangers cannot see its state", async (t) => {
  const env = voiceEnvironment(t);
  const { data: g } = await request(env, "u0", "/api/rooms", {
    mode: "private",
    seats: 6,
    name: "Первый",
  });
  const code = g.code;
  for (let i = 1; i < 6; i++) {
    const r = await request(env, "u" + i, "/api/join", {
      code,
      name: "Игрок " + i,
    });
    assert.equal(r.status, 200);
  }
  assert.equal(
    (await request(env, "stranger", `/api/rooms/${code}`)).status,
    400,
  );
  for (let i = 0; i < 6; i++)
    await request(env, "u" + i, `/api/rooms/${code}/action`, { type: "ready" });
  assert.equal(
    (await request(env, "u1", `/api/rooms/${code}/action`, { type: "start" }))
      .status,
    400,
  );
  const r = await request(env, "u0", `/api/rooms/${code}/action`, {
    type: "start",
  });
  assert.equal(r.status, 200);
  assert.equal(r.data.phase, "role");
  assert(r.data.players.every((p) => !p.role));
  const ownRoles = [];
  for (let i = 0; i < 6; i++)
    ownRoles.push(
      (await request(env, "u" + i, `/api/rooms/${code}`)).data.me.role,
    );
  assert.equal(ownRoles.filter((x) => x === "doctor").length, 1);
  assert.equal(ownRoles.filter((x) => x === "mafia").length, 1);
});
test("concurrent readiness commands do not overwrite each other", async (t) => {
  const env = voiceEnvironment(t);
  const { data: g } = await request(env, "u0", "/api/rooms", {
    mode: "private",
    seats: 6,
    name: "Первый",
  });
  await request(env, "u1", "/api/join", { code: g.code, name: "Второй" });
  await Promise.all([
    request(env, "u0", `/api/rooms/${g.code}/action`, { type: "ready" }),
    request(env, "u1", `/api/rooms/${g.code}/action`, { type: "ready" }),
  ]);
  const r = await request(env, "u0", `/api/rooms/${g.code}`);
  assert(r.data.players.every((p) => p.ready));
});

test("voice tokens contain only current grants and never expose secrets", async (t) => {
  const env = voiceEnvironment(t);
  const { data: g } = await request(env, "u", "/api/rooms", { seats: 6 });
  const r = await request(env, "u", `/api/rooms/${g.code}/voice`, {});
  assert.equal(r.status, 200);
  const [header, payload, signature] = r.data.rooms[0].token.split(".");
  const grant = JSON.parse(Buffer.from(payload, "base64url"));
  assert.equal(grant.sub, g.me.id);
  assert.equal(grant.video.canPublish, true);
  assert.deepEqual(grant.video.canPublishSources, ["microphone"]);
  assert.equal(grant.video.canPublishData, false);
  assert(!JSON.stringify(r.data).includes(env.LIVEKIT_API_SECRET));
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(env.LIVEKIT_API_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["verify"],
  );
  assert(
    await crypto.subtle.verify(
      "HMAC",
      key,
      Buffer.from(signature, "base64url"),
      new TextEncoder().encode(header + "." + payload),
    ),
  );
  assert.equal(
    (await request(env, "stranger", `/api/rooms/${g.code}/voice`, {})).status,
    400,
  );
});

test("a stale voice disconnect cannot pause the next phase", async (t) => {
  const env = voiceEnvironment(t);
  const { data: g } = await request(env, "u", "/api/rooms", { seats: 6 });
  await request(env, "u", `/api/rooms/${g.code}/action`, {
    type: "voice_error",
    voicePhaseSeq: g.phaseSeq - 1,
  });
  assert.equal((await load(env.DB, g.code)).game.voiceFailures, undefined);
  await request(env, "u", `/api/rooms/${g.code}/action`, {
    type: "voice_error",
    voicePhaseSeq: g.phaseSeq,
  });
  assert((await load(env.DB, g.code)).game.voiceFailures[g.me.id]);
});
