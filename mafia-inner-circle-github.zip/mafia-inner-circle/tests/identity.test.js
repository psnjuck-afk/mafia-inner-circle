import test from 'node:test';
import assert from 'node:assert/strict';
import { accountId } from '../server/identity.js';
const request=(headers={},path='/api/session')=>new Request('https://game.test'+path,{headers});
test('verified Sites ID remains the preferred identity',async()=>{
 assert.equal(await accountId(request({'oai-authenticated-user-id':'owner-id','oai-authenticated-user-email':'owner@example.test'})),'owner-id');
});
test('email-only Sites sign-in gets a stable private identity',async()=>{
 const id=await accountId(request({'oai-authenticated-user-email':'Owner@example.test'}));
 assert(id.startsWith('sites-email:'));
 assert(!id.includes('owner'));
 assert.equal(id,await accountId(request({'oai-authenticated-user-email':'owner@example.test'},'/api/rooms')));
 assert.notEqual(id,await accountId(request({'oai-authenticated-user-email':'other@example.test'})));
});
test('user-supplied query identity and display name do not grant access',async()=>{
 assert.equal(await accountId(request({'oai-authenticated-user-full-name':'Owner','x-user-id':'owner'},'/api/session?email=owner@example.test')),null);
 assert.equal(await accountId(request({'oai-authenticated-user-email':'invalid'})),null);
});
