import test from "node:test";
import assert from "node:assert/strict";
import { lines, narrationFor, narrationAudio } from "../server/narration.js";
test("narration uses public seat numbers, never nicknames or hidden roles", () => {
  const players = [{ id: "secret-id", name: "Private name", role: "mafia" }];
  const g = { phase: "dawn", players, result: { killed: "secret-id" } };
  assert.deepEqual(narrationFor(g), { key: "dawn_1", text: lines.dawn_1 });
  assert(!narrationFor(g).text.includes("Private name"));
  assert.equal(
    narrationFor({ ...g, phase: "turn", speakerId: "secret-id" }).key,
    "turn_1",
  );
});
test("arbitrary narration and inherited property keys cannot trigger paid synthesis", async (t) => {
  const mocked = t.mock.method(globalThis, "fetch", () => {
    throw new Error("must not fetch");
  });
  for (const key of ["hello from player", "__proto__", "constructor"]) {
    assert.equal(
      (
        await narrationAudio(
          { OPENAI_API_KEY: "test" },
          key,
          "https://test.local",
        )
      ).status,
      404,
    );
  }
  assert.equal(
    (await narrationAudio({}, "welcome", "https://test.local")).status,
    503,
  );
  assert.equal(mocked.mock.calls.length, 0);
});
test("concurrent narration requests share one generation and cached audio", async (t) => {
  let calls = 0;
  const cache = new Map();
  const previous = globalThis.caches;
  t.after(() => {
    if (previous === undefined) delete globalThis.caches;
    else globalThis.caches = previous;
  });
  globalThis.caches = {
    default: {
      match: async (key) => cache.get(key.url)?.clone(),
      put: async (key, value) => cache.set(key.url, value),
    },
  };
  t.mock.method(globalThis, "fetch", async (url, options) => {
    calls++;
    assert.equal(url, "https://api.openai.com/v1/audio/speech");
    const body = JSON.parse(options.body);
    assert.equal(body.input, lines.night);
    assert.equal(body.voice, "cedar");
    return new Response(new Uint8Array([1, 2, 3]), {
      headers: { "Content-Type": "audio/mpeg" },
    });
  });
  const get = () =>
    narrationAudio({ OPENAI_API_KEY: "test" }, "night", "https://test.local");
  const responses = await Promise.all([get(), get()]);
  assert.equal(calls, 1);
  assert.deepEqual(
    [...new Uint8Array(await responses[0].arrayBuffer())],
    [1, 2, 3],
  );
  assert.equal(responses[1].status, 200);
  assert.equal((await get()).status, 200);
  assert.equal(calls, 1);
});
