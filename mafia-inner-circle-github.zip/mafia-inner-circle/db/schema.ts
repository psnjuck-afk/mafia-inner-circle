import { sqliteTable, text, integer, index } from "drizzle-orm/sqlite-core";
export const rooms = sqliteTable(
  "rooms",
  {
    code: text("code").primaryKey(),
    state: text("state").notNull(),
    version: integer("version").notNull().default(0),
    mode: text("mode").notNull(),
    phase: text("phase").notNull(),
    seats: integer("seats").notNull(),
    count: integer("count").notNull(),
    updated: integer("updated").notNull(),
  },
  (t) => [
    index("idx_rooms_matchmaking").on(t.mode, t.phase, t.seats, t.updated),
  ],
);
export const members = sqliteTable("members", {
  account: text("account").primaryKey(),
  code: text("code").notNull(),
  updated: integer("updated").notNull(),
});
