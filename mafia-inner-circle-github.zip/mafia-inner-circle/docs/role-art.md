# Иллюстрации ролей

Финальные файлы для приложения: `src/assets/roles/civilian.webp`, `mafia.webp`, `detective.webp`, `doctor.webp`. Исходные сгенерированные PNG сохранены отдельно в рабочем пространстве; в сайт входят компактные WebP.

Режим: встроенный ImageGen, четыре отдельных запроса. Общая часть каждого промпта:

> Vertical 2:3 character portrait artwork for a mobile Mafia role card. One original fictional human character, waist-up, face clear and emotionally expressive, centered with breathing room around head and lower area for UI overlay. 1920s Prohibition-era underground club in New York, sophisticated editorial illustration with vintage lithograph and hand-painted gouache look, rich but slightly faded jewel colors, subtle aged paper grain and worn ink edges, dramatic cinematic lamp light, elegant and grounded, cohesive collectible series. Full-bleed art only: absolutely no words, letters, numbers, logo, frame, border, card shape, icons, or UI. Not photorealistic, not black-and-white, not cartoonish.

Индивидуальные части промптов:

- **Civilian:** A resolute ordinary city resident, a young woman in modest 1920s coat and cloche hat, in front of a warmly lit neighborhood storefront at dusk. Copper, muted amber and dusty burgundy accents; sympathetic but alert.
- **Mafia:** A confident clandestine mob figure in tailored pinstripe suit and fedora, silk tie, under the burgundy glow of a speakeasy doorway. Deep oxblood, plum and tarnished gold accents; calculating expression, no gun and no violence.
- **Detective:** A perceptive private detective in worn trench coat and 1920s felt hat, holding a small notebook, rain-slick street and blue gaslight behind. Muted indigo, petrol blue and aged brass accents; observant expression.
- **Doctor:** A compassionate 1920s physician in period medical coat with leather doctor's bag and stethoscope, warm lamplight in a late-night clinic. Muted emerald, teal and cream accents; composed and reassuring expression.

В интерфейсе название роли остаётся текстом поверх градиента и дублируется под картой после переворота. Так смысл карты не зависит только от изображения.

## Знак клуба и переворот

Знак `src/assets/club-mark.svg` изображает восемь мест вокруг круглого стола и центральную грань тайны. Он заменяет одиночную букву «M» на стартовом экране, в шапке, на рубашке карты и в favicon.

Переворот сделан как сжатие карты по горизонтали, замена рубашки на иллюстрацию в середине движения и раскрытие карты обратно. Закрытая карта не содержит лицевую сторону в разметке; портрет и крупное название появляются вместе. Это также исключает зеркальный текст на рубашке после анимации.
