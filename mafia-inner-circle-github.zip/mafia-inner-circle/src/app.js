import { screen, time } from "./screens.js";
import { GameAudio } from "./audio.js";
import { telegramHeaders, initializeTelegram } from "./telegram.js";
import { failedAvatar } from "./profile.js";
const root = document.querySelector("#app");
let pref = {};
try {
  pref = JSON.parse(localStorage.getItem("mafia-preferences") || "{}");
} catch {}
const s = {
  screen: pref.entered ? "home" : "onboarding",
  game: null,
  loading: true,
  mode: "quick",
  seats: 8,
  name: pref.name || "Вы",
  profile: null,
  joinCode: new URL(location.href).searchParams.get("room") || "",
  revealed: false,
  selected: null,
  modal: null,
  busy: false,
  offset: 0,
  toast: "",
  networkError: "",
  voiceConfigured: false,
  narratorConfigured: false,
  voiceStatus: "off",
  muted: true,
  micStatus: "Нажмите кнопку, чтобы разрешить доступ.",
  narration: pref.narration ?? true,
  narratorVolume: pref.narratorVolume ?? 0.8,
  playerVolume: pref.playerVolume ?? 0.9,
  music: pref.music ?? false,
  locallyMuted: [],
  playerInfo: null,
};
let toastTimer,
  lastSignature = "",
  lastAnnouncement = "",
  pollBusy = false,
  lastModal = null,
  flipBusy = false;
function save() {
  try {
    localStorage.setItem(
      "mafia-preferences",
      JSON.stringify({
        entered: true,
        name: s.profile?.source === "telegram" ? undefined : s.name,
        narration: s.narration,
        narratorVolume: s.narratorVolume,
        playerVolume: s.playerVolume,
        music: s.music,
      }),
    );
  } catch {}
}
function render() {
  const focus = document.activeElement?.id;
  root.innerHTML = screen(s);
  root.classList.toggle("busy", s.busy);
  if (focus) document.getElementById(focus)?.focus();
  if (s.modal && s.modal !== lastModal)
    root.querySelector('[role="dialog"] button')?.focus();
  lastModal = s.modal;
  updateClock();
  audio?.paintSpeakers();
}
function toast(message) {
  s.toast = message;
  render();
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    s.toast = "";
    root.querySelector(".toast")?.remove();
  }, 4000);
}
async function api(path, data) {
  const response = await fetch(path, {
    method: data === undefined ? "GET" : "POST",
    headers: { ...telegramHeaders(), ...(data === undefined ? {} : { "content-type": "application/json" }) },
    body: data === undefined ? undefined : JSON.stringify(data),
    signal: AbortSignal.timeout(12000),
  });
  let value;
  try {
    value = await response.json();
  } catch {
    throw new Error("Не удалось подключиться к столу. Перезагрузите страницу.");
  }
  if (!response.ok)
    throw new Error(value.error || "Не удалось выполнить действие");
  return value;
}
const audio = new GameAudio(() => s, toast, api, render);
function updateGame(g) {
  const previous = s.game;
  s.offset = g.serverNow - Date.now();
  s.game = g;
  s.loading = false;
  s.voiceConfigured = g.voiceConfigured;
  s.narratorConfigured = g.narratorConfigured;
  s.networkError = "";
  if (
    !previous ||
    g.matchId !== previous.matchId ||
    g.phaseSeq !== previous.phaseSeq
  ) {
    s.selected = null;
    if (
      !previous ||
      g.matchId !== previous.matchId ||
      (g.phase === "role" && previous.phase !== "role")
    )
      s.revealed = false;
    audio.silence();
    if (
      g.phase !== "turn" ||
      g.speakerId !== g.me.id ||
      g.turnState !== "speaking"
    )
      audio.stopTest();
  }
  const signature = JSON.stringify({ ...g, serverNow: 0 });
  if (signature !== lastSignature) {
    lastSignature = signature;
    render();
  }
  audio.update(g);
  const announcement = g.matchId + ":" + g.announcementId;
  if (announcement !== lastAnnouncement) {
    lastAnnouncement = announcement;
    audio.speak(g.narration?.text || g.announcement, false, g.narration?.key);
  }
}
async function action(type, extra = {}) {
  if (s.busy || !s.game) return;
  s.busy = true;
  render();
  try {
    const data = await api(`/api/rooms/${s.game.code}/action`, {
      type,
      phaseSeq: s.game.phaseSeq,
      eventId: crypto.randomUUID(),
      ...extra,
    });
    if (data.left) {
      s.game = null;
      s.screen = "home";
      s.modal = null;
      s.revealed = false;
      lastSignature = "";
      await audio.reset();
      render();
    } else updateGame(data);
  } catch (e) {
    toast(e.message);
    await refresh();
  } finally {
    s.busy = false;
    render();
  }
}
async function refresh() {
  if (pollBusy || !s.game) return;
  pollBusy = true;
  try {
    updateGame(await api("/api/rooms/" + s.game.code));
  } catch (e) {
    s.networkError = "Связь со столом прервана. Пытаемся вернуться…";
    render();
  } finally {
    pollBusy = false;
  }
}
function updateClock() {
  if (!s.game?.deadline) return;
  const seconds = Math.max(
    0,
    Math.ceil((s.game.deadline - Date.now() - s.offset) / 1000),
  );
  document.querySelectorAll(".timer").forEach((el) => {
    el.textContent = time(seconds);
    el.classList.toggle("urgent", seconds <= 10);
  });
}
async function initialize() {
  try {
    const session = await api("/api/session");
    s.profile = session.profile || null;
    if (s.profile?.name) s.name = s.profile.name;
    s.voiceConfigured = session.voiceConfigured;
    s.narratorConfigured = session.narratorConfigured;
    if (session.room) {
      try {
        updateGame(await api("/api/rooms/" + session.room));
      } catch (e) {
        s.networkError = e.message;
      }
    } else if (s.joinCode) s.screen = "join";
  } catch (e) {
    s.networkError = e.message;
  } finally {
    s.loading = false;
    render();
  }
}
root.addEventListener("error", (event) => {
  if (event.target.matches?.("img.avatar-photo")) failedAvatar(event.target);
}, true);
root.addEventListener("input", (event) => {
  const el = event.target;
  if (el.id === "nickname") {
    s.name = el.value;
    save();
  }
  if (el.id === "room-code") s.joinCode = el.value.toUpperCase();
  if (el.dataset.volume) {
    s[el.dataset.volume === "narrator" ? "narratorVolume" : "playerVolume"] =
      Number(el.value);
    audio.volumes();
    save();
  }
});
root.addEventListener("click", async (event) => {
  const button = event.target.closest("[data-action]");
  if (!button) {
    if (event.target.dataset.backdrop) {
      s.modal = null;
      audio.stopTest();
      render();
    }
    return;
  }
  if (button.disabled) return;
  const a = button.dataset.action,
    value = button.dataset.value;
  audio.unlock();
  try {
    if (a === "enter") {
      s.screen = "home";
      save();
      render();
    } else if (a === "home") {
      s.screen = "home";
      render();
    } else if (a === "setup") {
      s.mode = value;
      s.screen = "setup";
      render();
    } else if (a === "seats") {
      s.seats = Number(value);
      render();
    } else if (a === "join-screen") {
      s.screen = "join";
      render();
    } else if (a === "create" || a === "join") {
      if (s.busy) return;
      s.busy = true;
      render();
      try {
        const g = await api(
          a === "create" ? "/api/rooms" : "/api/join",
          a === "create"
            ? {
                mode: s.mode,
                seats: s.seats,
                name: s.name || "Гость",
              }
            : { name: s.name || "Гость", code: s.joinCode },
        );
        s.modal = null;
        updateGame(g);
      } finally {
        s.busy = false;
        render();
      }
    } else if (["settings", "rules", "history", "checks"].includes(a)) {
      s.modal = a;
      render();
    } else if (a === "close-modal") {
      s.modal = null;
      audio.stopTest();
      render();
    } else if (a === "leave") {
      s.modal = "leave";
      render();
    } else if (a === "confirm-leave") await action("leave");
    else if (a === "ready") {
      if (!s.game.players.find((p) => p.id === s.game.me.id).ready)
        await audio.permission();
      await action("ready");
    } else if (a === "start") await action("start");
    else if (a === "role-ready") await action("role_ready");
    else if (a === "my-role") {
      s.revealed = false;
      s.modal = "my-role";
      render();
    } else if (a === "flip") {
      if (flipBusy) return;
      flipBusy = true;
      const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
      button.classList.add("flip-out");
      setTimeout(
        () => {
          s.revealed = !s.revealed;
          render();
          root.querySelector(".role-flip")?.classList.add("flip-in");
          setTimeout(
            () => {
              flipBusy = false;
            },
            reduced ? 0 : 260,
          );
        },
        reduced ? 0 : 220,
      );
    } else if (a === "speak") {
      await audio.permission();
      s.muted = false;
      await action("speak");
    } else if (a === "pass") await action("pass");
    else if (a === "skip-reply") await action("skip_reply");
    else if (a === "target") {
      s.selected = value;
      render();
    } else if (a === "confirm-night")
      await action("night", { target: s.selected });
    else if (a === "skip-night") await action("night", { target: "skip" });
    else if (a === "confirm-vote") await action("vote", { target: s.selected });
    else if (a === "react") await action("react", { emoji: value });
    else if (a === "presence") await action("presence");
    else if (a === "postgame") await action("postgame");
    else if (a === "copy") {
      try {
        await navigator.clipboard.writeText(s.game.code);
        toast("Код комнаты скопирован");
      } catch {
        toast("Код комнаты: " + s.game.code);
      }
    } else if (a === "mic") {
      const next = !s.muted;
      await audio.mute(next);
      s.muted = next;
      render();
    } else if (a === "check-mic") {
      s.modal = "mic";
      render();
    } else if (a === "start-mic-test") {
      try {
        await audio.testMic();
        s.micStatus = "Микрофон работает. Говорите и следите за полосой.";
      } catch {
        s.micStatus =
          "Доступ к микрофону не получен. Разрешите его в настройках браузера или Telegram.";
      }
      render();
    } else if (a === "narration") {
      s.narration = !s.narration;
      save();
      if (!s.narration) audio.silence();
      render();
    } else if (a === "music") {
      s.music = !s.music;
      save();
      audio.music(s.music);
      render();
    } else if (a === "retry-voice") {
      audio.signature = "";
      await audio.update(s.game);
    } else if (a === "test-voice")
      audio.speak(
        "Добро пожаловать в клуб. У каждого здесь своя тайна. Посмотрим, кому удастся её сохранить.",
        true,
        "welcome",
      );
    else if (a === "player-info") {
      s.playerInfo = value;
      s.modal = "player";
      render();
    } else if (a === "mute-player") {
      const id = s.playerInfo;
      s.locallyMuted = s.locallyMuted.includes(id)
        ? s.locallyMuted.filter((x) => x !== id)
        : [...s.locallyMuted, id];
      audio.volumes();
      render();
    } else if (a === "refresh") {
      if (s.game) await refresh();
      else await initialize();
    }
  } catch (e) {
    toast(
      e.name === "NotAllowedError"
        ? "Разрешите доступ к микрофону, чтобы говорить."
        : e.message,
    );
  }
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && s.modal) {
    s.modal = null;
    audio.stopTest();
    render();
  }
  if (event.key === "Tab" && s.modal) {
    const buttons = [
      ...document.querySelectorAll(
        '[role="dialog"] button:not(:disabled),[role="dialog"] input,[role="dialog"] select',
      ),
    ];
    const first = buttons[0],
      last = buttons.at(-1);
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last?.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first?.focus();
    }
  }
});
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    s.revealed = false;
    if (s.modal === "my-role") s.modal = null;
    audio.stopTest();
    render();
  } else refresh();
});
window.addEventListener("online", refresh);
setInterval(() => {
  if (!document.hidden && !s.busy) refresh();
}, 1500);
setInterval(updateClock, 200);
initializeTelegram();
render();
initialize();
