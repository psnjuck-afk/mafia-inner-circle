// Only the server may turn initData into an authenticated player profile.
export function telegramHeaders() {
  const raw = window.Telegram?.WebApp?.initData;
  return raw ? { authorization: `tma ${raw}` } : {};
}
export function initializeTelegram() {
  const app = window.Telegram?.WebApp;
  if (!app?.initData) return;
  app.ready();
  app.expand();
}
