import { Room, RoomEvent, Track } from "livekit-client";
import { telegramHeaders } from "./telegram.js";
export class GameAudio {
  constructor(getState, notify, api, onChange = () => {}) {
    this.state = getState;
    this.notify = notify;
    this.api = api;
    this.onChange = onChange;
    this.activeByRoom = new Map();
    this.narrationGeneration = 0;
    this.rooms = [];
    this.generation = 0;
    this.signature = "";
  }
  unlock() {
    try {
      this.context ??= new (window.AudioContext || window.webkitAudioContext)();
      this.context.resume();
    } catch {}
  }
  async speak(text, force = false, key) {
    const s = this.state();
    if (!s.narration && !force) return;
    this.silence();
    const gen = this.narrationGeneration;
    if (
      key &&
      s.narratorConfigured &&
      Date.now() > (this.narrationBackoff || 0)
    ) {
      try {
        const abort = new AbortController();
        this.narrationAbort = abort;
        const timeout = setTimeout(() => abort.abort(), 4500);
        let bytes;
        try {
          const response = await fetch(
            `/api/narration/${encodeURIComponent(key)}`,
            { signal: abort.signal, headers: telegramHeaders() },
          );
          if (!response.ok) throw new Error("Narration unavailable");
          bytes = await response.arrayBuffer();
        } finally {
          clearTimeout(timeout);
        }
        if (gen !== this.narrationGeneration) return;
        this.unlock();
        const buffer = await this.context.decodeAudioData(bytes);
        if (gen !== this.narrationGeneration) return;
        this.narratorGain ??= this.context.createGain();
        this.narratorGain.disconnect();
        this.narratorGain.connect(this.context.destination);
        this.narratorGain.gain.value = this.state().narratorVolume;
        this.narratorSource = this.context.createBufferSource();
        this.narratorSource.buffer = buffer;
        this.narratorSource.connect(this.narratorGain);
        this.narratorSource.start();
        return;
      } catch {
        if (gen !== this.narrationGeneration) return;
        this.narrationBackoff = Date.now() + 60000;
        this.notify(
          "Студийная озвучка недоступна. Временно включён голос устройства.",
        );
      }
    }
    if (!("speechSynthesis" in window)) {
      if (force)
        this.notify("На устройстве нет озвучки. Объявления доступны текстом.");
      return;
    }
    const voices = speechSynthesis
      .getVoices()
      .filter((v) => v.lang.toLowerCase().startsWith("ru"));
    const score = (v) =>
      (/premium|enhanced|natural|online|google/i.test(v.name) ? 10 : 0) +
      (!v.localService ? 2 : 0);
    voices.sort((a, b) => score(b) - score(a));
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "ru-RU";
    utterance.rate = 1;
    utterance.pitch = 0.95;
    utterance.volume = s.narratorVolume;
    if (voices[0]) utterance.voice = voices[0];
    speechSynthesis.speak(utterance);
  }
  silence() {
    this.narrationGeneration++;
    this.narrationAbort?.abort();
    try {
      this.narratorSource?.stop();
    } catch {}
    this.narratorSource = null;
    if ("speechSynthesis" in window) speechSynthesis.cancel();
  }
  setStatus(status) {
    if (this.state().voiceStatus === status) return;
    this.state().voiceStatus = status;
    this.onChange();
  }
  paintSpeakers() {
    const ids = new Set([...this.activeByRoom.values()].flat());
    document
      .querySelectorAll("[data-player]")
      .forEach((el) =>
        el.classList.toggle("talking", ids.has(el.dataset.player)),
      );
  }
  report(game, type) {
    return this.api(`/api/rooms/${game.code}/action`, {
      type,
      voicePhaseSeq: game.phaseSeq,
      eventId: crypto.randomUUID(),
    }).catch(() => {});
  }
  retryLater(gen) {
    clearTimeout(this.reconnectTimer);
    this.reconnectTimer = setTimeout(() => {
      if (gen !== this.generation) return;
      this.signature = "";
      this.update(this.state().game);
    }, 5000);
  }
  music(on) {
    if (!on && !this.musicGain) return;
    this.unlock();
    if (!this.context) return;
    if (!this.musicGain) {
      this.musicGain = this.context.createGain();
      this.musicGain.gain.value = 0;
      this.musicGain.connect(this.context.destination);
      for (const f of [110, 164.81, 220]) {
        const o = this.context.createOscillator();
        o.type = "sine";
        o.frequency.value = f;
        o.connect(this.musicGain);
        o.start();
      }
    }
    const g = this.state().game;
    this.musicGain.gain.setTargetAtTime(
      on ? (g?.phase === "turn" ? 0.003 : 0.012) : 0,
      this.context.currentTime,
      0.5,
    );
  }
  async testMic() {
    if (!navigator.mediaDevices?.getUserMedia)
      throw new Error("Микрофон недоступен в этом браузере");
    this.stopTest();
    this.testStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true },
      video: false,
    });
    this.unlock();
    if (!this.context) return;
    this.analyser = this.context.createAnalyser();
    this.analyser.fftSize = 256;
    this.source = this.context.createMediaStreamSource(this.testStream);
    this.source.connect(this.analyser);
    const data = new Uint8Array(256);
    this.meter = setInterval(() => {
      this.analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (const x of data) sum += (x - 128) ** 2;
      const level = Math.min(1, Math.sqrt(sum / 256) / 25);
      document
        .querySelectorAll(".mic-meter")
        .forEach((e) => e.style.setProperty("--level", level));
    }, 100);
  }
  stopTest() {
    clearInterval(this.meter);
    this.source?.disconnect();
    this.testStream?.getTracks().forEach((t) => t.stop());
    this.testStream = null;
    document
      .querySelectorAll(".mic-meter")
      .forEach((e) => e.style.setProperty("--level", 0));
  }
  async permission() {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true },
      video: false,
    });
    stream.getTracks().forEach((t) => t.stop());
  }
  async update(game) {
    this.music(this.state().music);
    const signature = game?.voiceConfigured
      ? game.code + ":" + game.phaseSeq
      : "";
    if (signature === this.signature) return;
    this.signature = signature;
    clearTimeout(this.reconnectTimer);
    const gen = ++this.generation;
    await this.disconnectRooms();
    if (gen !== this.generation) return;
    if (!signature) {
      this.setStatus("off");
      return;
    }
    if (!game.voice.rooms.length) {
      this.setStatus("silent");
      return;
    }
    this.setStatus("connecting");
    try {
      const info = await this.api(`/api/rooms/${game.code}/voice`, {});
      if (gen !== this.generation || info.phaseSeq !== game.phaseSeq) return;
      for (const channel of info.rooms) {
        const room = new Room({ adaptiveStream: true, dynacast: true });
        room._canPublish = channel.publish;
        room._elements = new Set();
        // Keep connecting rooms visible to reset(), so a phase change can close them.
        this.rooms.push(room);
        room.on(
          RoomEvent.TrackSubscribed,
          (track, publication, participant) => {
            if (gen === this.generation && track.kind === Track.Kind.Audio) {
              const element = track.attach();
              element.dataset.voicePlayer = participant.identity;
              room._elements.add(element);
              document.querySelector("#remote-audio").append(element);
              this.volumes();
            }
          },
        );
        room.on(RoomEvent.TrackUnsubscribed, (track) =>
          track.detach().forEach((el) => {
            room._elements.delete(el);
            el.remove();
          }),
        );
        room.on(RoomEvent.ActiveSpeakersChanged, (people) => {
          if (gen !== this.generation) return;
          this.activeByRoom.set(
            room,
            people.map((p) => p.identity),
          );
          this.paintSpeakers();
        });
        room.on(RoomEvent.Reconnecting, () => {
          if (gen !== this.generation) return;
          this.setStatus("reconnecting");
          this.report(game, "voice_error");
        });
        room.on(RoomEvent.Reconnected, () => {
          if (gen !== this.generation) return;
          if (this.rooms.every((r) => r.state === "connected")) {
            this.setStatus("connected");
            this.report(game, "voice_ok");
          }
        });
        room.on(RoomEvent.Disconnected, () => {
          if (gen !== this.generation) return;
          this.setStatus("error");
          this.activeByRoom.delete(room);
          this.paintSpeakers();
          this.report(game, "voice_error");
          this.retryLater(gen);
        });
        await room.connect(info.url, channel.token);
        if (gen !== this.generation) {
          await room.disconnect();
          return;
        }
        try {
          await room.startAudio();
        } catch {
          this.notify("Нажмите «Восстановить звук» в настройках.");
        }
        if (channel.publish && !this.state().muted)
          await room.localParticipant.setMicrophoneEnabled(true);
      }
      if (gen !== this.generation) return;
      this.setStatus("connected");
      await this.report(game, "voice_ok");
    } catch (e) {
      if (gen !== this.generation) return;
      await this.disconnectRooms();
      if (gen !== this.generation) return;
      this.setStatus("error");
      this.report(game, "voice_error");
      this.retryLater(gen);
    }
  }
  async mute(muted) {
    for (const room of this.rooms)
      if (room._canPublish)
        await room.localParticipant.setMicrophoneEnabled(!muted);
  }
  volumes() {
    const s = this.state();
    if (this.narratorGain) this.narratorGain.gain.value = s.narratorVolume;
    document
      .querySelectorAll("#remote-audio audio")
      .forEach(
        (e) =>
          (e.volume = s.locallyMuted.includes(e.dataset.voicePlayer)
            ? 0
            : s.playerVolume),
      );
  }
  async disconnectRooms() {
    const rooms = this.rooms;
    this.rooms = [];
    for (const room of rooms) {
      room.removeAllListeners();
      room._elements?.forEach((el) => el.remove());
      this.activeByRoom.delete(room);
    }
    this.paintSpeakers();
    await Promise.allSettled(rooms.map((r) => r.disconnect()));
  }
  async reset() {
    clearTimeout(this.reconnectTimer);
    this.setStatus("off");
    this.signature = "";
    this.generation++;
    this.stopTest();
    this.silence();
    await this.disconnectRooms();
  }
}
