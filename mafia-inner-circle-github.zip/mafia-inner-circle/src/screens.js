import {
  roles,
  reactions,
  composition,
  icons,
  esc,
  reactionIcon,
} from "./data.js";
import { avatar, profileCard, nameField } from "./profile.js";
const btn = (label, action, attrs = "", secondary = false) =>
  `<button class="btn ${secondary ? "secondary " : ""}wide" data-action="${action}" ${attrs}>${label}</button>`;
const name = (g, id) =>
  id === "skip" ? "Никого" : g.players.find((p) => p.id === id)?.name || "—";
const remaining = (g, offset) =>
  Math.max(0, Math.ceil((g.deadline - Date.now() - offset) / 1000));
export const time = (s) =>
  `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
function header(s) {
  return `<header class="top"><button class="iconbtn" data-action="${s.game ? "leave" : "home"}" aria-label="${s.game ? "Покинуть стол" : "На главную"}">‹</button><div class="brand-lockup"><img src="/assets/club-mark.svg" class="brand-mark" alt=""><span class="brand">MAFIA</span></div><button class="iconbtn" data-action="settings" aria-label="Звук и правила">⋯</button></header>`;
}
const setup = (s) =>
  `${nameField(s)}<div class="seat-control"><div class="row"><strong>Мест за столом</strong><b>${s.seats}</b></div><div class="seat-options">${[6, 7, 8, 9, 10].map((n) => `<button data-action="seats" data-value="${n}" aria-pressed="${n === s.seats}" class="${n === s.seats ? "selected" : ""}">${n}</button>`).join("")}</div>${roleCounts(composition(s.seats))}</div>`;
function roleCounts(c) {
  return `<div class="role-counts">${Object.entries(c)
    .map(
      ([r, n]) =>
        `<span><i class="role-dot ${r}"></i>${roles[r].name}: <b>${n}</b></span>`,
    )
    .join("")}</div>`;
}
function timer(s, label) {
  return `<div class="clock-block"><span class="clock-label">${label}</span><span class="timer" data-deadline="${s.game.deadline}">${time(remaining(s.game, s.offset))}</span></div>`;
}
function phaseHead(s, title, kicker, label) {
  return `<div class="phase-head"><div class="eyebrow">${kicker}</div><h1>${title}</h1>${s.game.deadline ? timer(s, label) : ""}</div>`;
}
function table(s) {
  const g = s.game,
    me = g.me;
  let people = [...g.players];
  const own = people.findIndex((p) => p.id === me.id);
  people = people.slice(own).concat(people.slice(0, own));
  const selectable = g.phase === "night" && me.alive && me.role !== "civilian";
  const center =
    g.phase === "night"
      ? "ГОРОД СПИТ"
      : g.phase === "turn"
        ? g.turnState === "offer"
          ? "СЛОВО ЗА ВАМИ"
          : "СЛУШАЙТЕ ДРУГ ДРУГА"
        : "ПОДПОЛЬНЫЙ КЛУБ";
  return `<div class="table-wrap" aria-label="Игровой стол"><div class="table"></div><div class="table-center"><img src="/assets/club-mark.svg" alt=""><span>${g.phase === "turn" && g.speakerId !== me.id && g.turnState === "offer" ? "ПЕРЕДАЁМ СЛОВО" : center}</span></div>${people
    .map((p, i) => {
      const a = ((90 + (i * 360) / g.seats) * Math.PI) / 180,
        x = 50 + 37 * Math.cos(a),
        y = 49 + 36 * Math.sin(a),
        reaction = g.reactions.findLast((r) => r.id === p.id),
        allowed = me.targets.includes(p.id);
      return `<button class="player ${p.alive ? "" : "dead"} ${g.phase === "turn" && p.id === g.speakerId ? "has-floor" : ""} ${s.selected === p.id ? "selected" : ""} ${selectable && !allowed ? "unavailable" : ""}" style="left:${x}%;top:${y}%" data-action="${selectable ? "target" : "player-info"}" data-value="${p.id}" data-player="${p.id}" ${selectable && !allowed ? "disabled" : ""} aria-label="${esc(p.name)}${p.alive ? "" : ", выбыл"}">${avatar(p)}<span class="player-name">${esc(p.name)}</span><span class="seat-number">${g.players.findIndex((x) => x.id === p.id) + 1}${p.id === me.id ? " · вы" : ""}${!p.alive ? " · выбыл" : ""}</span>${reaction ? `<span class="reaction-bubble">${reactionIcon(reaction.emoji)}</span>` : ""}</button>`;
    })
    .join("")}</div>`;
}
function host(s) {
  return `<div class="host-line"><span class="host-symbol">◉</span><div><span class="eyebrow">ВЕДУЩИЙ · ИГРА</span><p>${esc(s.game.announcement)}</p></div></div>`;
}
function voiceStatus(s) {
  const labels = {
    off: "Голосовой чат готовится к открытию",
    connecting: "Подключаем голос…",
    connected: "Голос подключён",
    reconnecting: "Восстанавливаем связь…",
    error: "Не удалось подключить голос",
    silent: "Ночной режим · общий канал закрыт",
  };
  return `<div class="voice-status ${s.voiceStatus}" role="status"><i></i><span>${labels[s.voiceStatus] || labels.off}</span>${["error", "reconnecting"].includes(s.voiceStatus) ? '<button class="text-btn" data-action="retry-voice">Повторить</button>' : ""}</div>`;
}
function mic(s) {
  const enabled = s.game.voice.publish && s.voiceStatus === "connected";
  const label = !enabled
    ? "Сейчас вы слушаете"
    : s.muted
      ? "Микрофон выключен"
      : "Микрофон включён";
  return `${voiceStatus(s)}<button class="mic-control ${s.muted ? "muted-mic" : ""}" data-action="mic" ${!enabled ? "disabled" : ""} aria-label="${label}">${icons[s.muted || !enabled ? "muted" : "mic"]}<span>${label}</span><i class="mic-meter"></i></button>`;
}
function react(s) {
  const g = s.game,
    allowed = g.phase === "turn" || !g.me.alive;
  return allowed
    ? `<div class="reaction-row">${reactions.map((e) => `<button data-action="react" data-value="${e}" aria-label="Реакция ${e}">${reactionIcon(e)}</button>`).join("")}</div>`
    : "";
}
function roleCard(s, small = false) {
  const r = roles[s.game.me.role];
  if (!r) return "";
  return `<div class="role-stage center"><div class="eyebrow">ТОЛЬКО ДЛЯ ВАШИХ ГЛАЗ</div><h1 class="role-heading">Ваша карта</h1><button class="role-flip ${small ? "compact" : ""}" data-action="flip" aria-label="${s.revealed ? "Скрыть карту" : "Перевернуть карту"}" aria-pressed="${s.revealed}"><span class="role-card-inner">${s.revealed ? `<span class="role-card-face role-card-front"><img class="role-portrait" src="/assets/roles/${s.game.me.role}.webp" alt="${r.name}"><span class="role-card-label"><span class="role-card-kicker">ВАША РОЛЬ</span><strong>${r.name}</strong></span></span>` : `<span class="role-card-face role-card-back"><span class="card-ornament">✦</span><img src="/assets/club-mark.svg" class="card-mark" alt=""><span class="card-caption">THE INNER CIRCLE</span></span>`}</span></button><p class="role-hint muted">${s.revealed ? r.description : "Нажмите на карту, чтобы узнать свою роль."}</p>${s.revealed && s.game.me.role === "mafia" ? `<p class="gold">${s.game.me.allies.length ? "Ваш напарник: " + s.game.me.allies.map((id) => esc(name(s.game, id))).join(", ") : "Вы — единственная мафия за столом."}</p>` : ""}${s.revealed ? `<p class="small muted">${r.hint}</p>` : ""}</div>`;
}
function roster(g) {
  return `<div class="roster">${g.players.map((p) => `<div class="member">${avatar(p)}<strong>${esc(p.name)}</strong><small>${p.bot ? "Виртуальный игрок" : p.ready ? "Готов" : "Готовится"}</small>${p.ready ? '<span class="ready">✓</span>' : ""}</div>`).join("")}${Array.from({ length: g.seats - g.players.length }, () => '<div class="member empty-seat"><span class="avatar">+</span><strong>Свободно</strong><small>Ждём игрока</small></div>').join("")}</div>`;
}
function nightPanel(s) {
  const g = s.game,
    me = g.me;
  if (!me.alive) return ghost(s);
  if (me.role === "civilian")
    return `<div class="phase-panel"><strong>Ваша задача — дождаться утра</strong><p>Ночных действий у мирного жителя нет. Вы не слышите разговор мафии.</p></div>`;
  const prompt = {
    mafia: "Кого убрать?",
    doctor: "Кого защитить?",
    detective: "Кого проверить?",
  }[me.role];
  return `<div class="phase-panel"><strong>${prompt}</strong><p>${roles[me.role].hint}</p>${me.nightChoice ? `<p class="gold">✓ Принято: ${esc(name(g, me.nightChoice))}. До рассвета можно изменить.</p>` : "<p>Выберите персонажа за столом и подтвердите.</p>"}${me.teammateChoices.map((p) => `<p class="ally-choice">${esc(name(g, p.id))}: ${p.choice ? esc(name(g, p.choice)) : "пока выбирает"}${p.choice && me.nightChoice && p.choice !== me.nightChoice ? " · цели не совпадают" : ""}</p>`).join("")}</div><div class="actions compact-actions">${btn(s.selected ? "Подтвердить: " + esc(name(g, s.selected)) : "Выберите игрока", "confirm-night", !s.selected ? "disabled" : "")}${btn("Пропустить ночной ход", "skip-night", "", true)}${me.role === "mafia" ? `<div class="channel-note">Закрытый разговор · слышит только живая мафия</div>${mic(s)}` : ""}</div>`;
}
function ghost(s) {
  return `<div class="ghost-banner"><strong>Вы в комнате призраков</strong><p>Слушайте дневное обсуждение. Ваш голос и реакции доступны только выбывшим. Роли откроются после финала.</p></div>${mic(s)}`;
}
function turnPanel(s) {
  const g = s.game,
    me = g.me,
    own = g.speakerId === me.id,
    p = g.players.find((p) => p.id === g.speakerId);
  return `${!me.alive ? ghost(s) : ""}<div class="phase-panel"><strong>${own ? "Ваше слово" : esc(p?.name)}${g.turnState === "offer" ? " · приглашение" : " · говорит"}</strong><p>${own ? "Закончили мысль? Передайте слово, не дожидаясь таймера." : "Следующий: " + esc(name(g, g.queue?.[g.turnIndex + 1]))}</p></div>${react(s)}${own && me.alive ? `<div class="actions compact-actions">${g.turnState === "offer" ? `${btn("Говорить", "speak")}${btn("Пропустить", "pass", "", true)}` : btn("Передать слово " + icons.arrow, "pass")}${mic(s)}</div>` : `<div class="turn-wait">${me.alive ? "Слушайте. Игра пригласит вас в вашу очередь." : "Вы наблюдаете за партией."}</div>`}${me.alive && ["main", "reply"].includes(g.turnKind) && !own ? `<button class="text-btn" data-action="skip-reply">${me.replySkipped ? "Вернуть меня в круг ответов" : "Пропустить мой короткий ответ"}</button>` : ""}`;
}
function votes(s) {
  const g = s.game,
    me = g.me;
  return `<p class="muted center">${me.alive ? "Выберите подозреваемого или оставьте всех за столом." : "Вы наблюдаете. Голосуют только живые игроки."}</p><div class="vote-list">${g.players
    .filter((p) => p.alive && (!g.runoff || g.nominees.includes(p.id)))
    .map(
      (p) =>
        `<button class="vote-option ${s.selected === p.id || me.vote === p.id ? "chosen" : ""}" data-action="target" data-value="${p.id}" ${!me.targets.includes(p.id) || me.vote ? "disabled" : ""}>${avatar(p)}<strong>${esc(p.name)}</strong><span>${me.vote === p.id || s.selected === p.id ? "✓" : "○"}</span></button>`,
    )
    .join(
      "",
    )}<button class="vote-option ${s.selected === "skip" || me.vote === "skip" ? "chosen" : ""}" data-action="target" data-value="skip" ${!me.alive || me.vote ? "disabled" : ""}><strong>Никого не исключать</strong><span>${s.selected === "skip" || me.vote === "skip" ? "✓" : "○"}</span></button></div><p class="small muted center">${g.votesCast} из ${g.players.filter((p) => p.alive).length} голосов принято. Выборы пока скрыты.</p>${me.alive ? btn(me.vote ? "Голос принят" : "Подтвердить голос", "confirm-vote", !s.selected || me.vote ? "disabled" : "") : ""}<p class="small muted center">После подтверждения голос изменить нельзя. Пропуск времени = «Никого».</p>`;
}
function voteBreakdown(g) {
  if (!g.lastVote) return "";
  return `<details class="details"><summary>Кто за кого голосовал</summary>${Object.entries(
    g.lastVote.votes,
  )
    .map(
      ([id, target]) =>
        `<div class="row small"><span>${esc(name(g, id))}</span><b>${esc(name(g, target))}</b></div>`,
    )
    .join("")}</details>`;
}
function reveal(g) {
  return `<div class="role-grid">${g.players.map((p) => `<div class="role-tile"><img src="/assets/roles/${p.role}.webp" alt="">${avatar(p)}<div><b>${esc(p.name)}</b><span>${roles[p.role]?.name || "—"}</span></div></div>`).join("")}</div>`;
}
function history(g) {
  return g.history.length
    ? `<div class="timeline">${g.history
        .map(
          (e) =>
            `<div><b>${e.day ? "День / ночь " + e.day : "Начало"} · ${esc(e.text)}</b>${["gameover", "postgame"].includes(g.phase) && e.type === "night" ? `<span>Цель мафии: ${esc(name(g, e.mafiaTarget))}<br>Доктор: ${esc(name(g, e.heal))}${e.saved ? " · спасение" : ""}${e.check ? "<br>Проверка: " + esc(e.check.name) + " — " + (e.check.mafia ? "мафия" : "не мафия") : ""}</span>` : ""}${
              e.type === "vote"
                ? Object.entries(e.votes)
                    .map(
                      ([id, t]) =>
                        `<span class="history-vote">${esc(name(g, id))} → ${esc(name(g, t))}</span>`,
                    )
                    .join("")
                : ""
            }</div>`,
        )
        .join("")}</div>`
    : '<p class="muted">История появится после первой ночи.</p>';
}
const rulesHTML = `<div class="rules-copy"><h3>Стол и роли</h3><p>6–7 игроков: одна мафия. 8–10: две. Детектив и доктор есть всегда. Роли погибших скрыты до финала.</p><h3>День</h3><p>10 секунд на принятие слова. Основная речь — до 40 секунд, ответ — до 15. «Передать слово» сразу завершает ваш ход. Тишина посреди речи не прерывает очередь.</p><h3>Ночь · 60 секунд</h3><p>Все роли действуют одновременно. Две мафии должны подтвердить одну цель. Пропуск или разные цели — без убийства. Ночь не заканчивается раньше.</p><p>Доктор лечит себя один раз за партию; одну цель нельзя лечить две ночи подряд. Детектив узнаёт только «мафия / не мафия».</p><h3>Голосование · 30 секунд</h3><p>После подтверждения голос окончательный. Побеждает вариант с наибольшим числом голосов. Пропуск равен «Никого не исключать». Ничья между игроками: защита по 20 секунд и один повторный тур на 20 секунд. Повторная ничья или лидерство «Никого» — без исключения.</p><h3>Победа</h3><p>Мафии не осталось — победил город. Мафии не меньше остальных живых — победила мафия. После десяти дневных голосований без победителя — ничья.</p><h3>Связь и выход</h3><p>На возвращение — 60 секунд. После этого — техническое выбывание на границе фазы. Новые игроки присоединяются только до следующей партии.</p></div>`;
export function screen(s) {
  let content = "";
  const g = s.game;
  if (s.loading)
    return '<section class="screen loading"><img src="/assets/club-mark.svg" alt=""><h1>Открываем клуб</h1><p class="muted">Подключаемся к вашему столу…</p></section>';
  if (g?.pausedUntil)
    return `<section class="screen">${header(s)}${phaseHead(s, "Возвращаем звук", "ТЕХНИЧЕСКАЯ ПАУЗА", "На восстановление")}<div class="result-scene"><img src="/assets/club-mark.svg" alt=""><p class="muted">У нескольких игроков пропала голосовая связь. Игровые таймеры приостановлены.</p>${btn("Восстановить звук", "retry-voice")}</div></section>${s.modal ? modal(s) : ""}`;
  if (!g) {
    if (s.screen === "onboarding")
      content = `<div class="welcome"><img class="welcome-mark" src="/assets/club-mark.svg" alt=""><div class="eyebrow">THE INNER CIRCLE</div><h1 class="title">У каждого<br>есть тайна.</h1><p class="muted">Голосовая мафия за одним столом.<br>Партию ведёт сама игра.</p></div><div class="actions">${s.profile ? profileCard(s) : ""}${btn("Войти в клуб", "enter")}<p class="small muted center">6–10 игроков · 4 роли · один город</p></div>`;
    else if (s.screen === "setup")
      content = `<div class="eyebrow">${s.mode === "private" ? "ЧАСТНЫЙ СТОЛ" : "БЫСТРАЯ ИГРА"}</div><h1 class="title">Соберёмся<br>за столом.</h1><p class="muted">${s.mode === "private" ? "Пригласите друзей по коду. Создатель комнаты тоже участвует в партии." : "Подбор среди настоящих игроков с тем же размером стола."}</p><div class="card">${setup(s)}</div>${!s.voiceConfigured ? '<div class="notice">Голосовой чат готовится к открытию. Комнату уже можно создать; начать партию получится после подключения звука.</div>' : ""}<div class="actions">${btn(s.mode === "private" ? "Создать комнату" : "Найти стол", "create", s.busy ? "disabled" : "")}</div>`;
    else if (s.screen === "join")
      content = `<div class="eyebrow">ЧАСТНЫЙ СТОЛ</div><h1 class="title">Ваши уже ждут?</h1>${nameField(s)}<label class="field-label" for="room-code">Код из шести символов</label><input id="room-code" class="field room-code" maxlength="6" autocomplete="off" autocapitalize="characters" placeholder="ABC234" value="${esc(s.joinCode)}"><div class="actions">${btn("Присоединиться", "join", s.busy ? "disabled" : "")}</div>`;
    else
      content = `<div class="home-main">${profileCard(s)}<div class="eyebrow">ПОДПОЛЬНЫЙ КЛУБ</div><h1 class="title">Стол ждёт<br>тебя.</h1><p class="muted">Город уснёт. Кто-то не проснётся.<br>Слушай внимательно.</p><button class="mode featured" data-action="setup" data-value="quick"><img src="/assets/club-mark.svg" alt=""><span><strong>Найти игру</strong><small>Голосовой стол на 6–10 человек</small></span>${icons.arrow}</button><button class="mode" data-action="setup" data-value="private"><span class="symbol">♧</span><span><strong>Создать комнату</strong><small>Собраться с друзьями</small></span></button><button class="text-btn wide" data-action="join-screen">Войти по коду</button></div><div class="home-footer"><span>ВЕДУЩИЙ — САМА ИГРА</span><button class="text-btn" data-action="rules">Правила</button></div>`;
  } else if (["lobby", "postgame"].includes(g.phase))
    content = `<div class="eyebrow">${g.mode === "quick" ? "ПОДБОР ИГРОКОВ" : "ЧАСТНЫЙ СТОЛ"}</div><h1 class="title">${g.phase === "postgame" ? "Ещё одну?" : "Все в сборе?"}</h1>${host(s)}<div class="card lobby-card"><div class="row"><div><span class="small muted">КОД КОМНАТЫ</span><div class="code">${g.code}</div></div><button class="btn secondary" data-action="copy">Копировать</button></div><p class="small muted">${g.players.length} / ${g.seats} мест · ${g.players.filter((p) => p.ready).length} готовы</p>${roster(g)}${roleCounts(g.composition)}</div><div class="notice">${g.voiceConfigured ? "Проверьте микрофон, затем подтвердите готовность." : "Голосовой чат готовится к открытию. Когда связь будет подключена, здесь можно будет начать партию."}</div><button class="text-btn" data-action="check-mic">Проверить микрофон</button>${g.voiceConfigured ? mic(s) : ""}<div class="actions">${btn(g.players.find((p) => p.id === g.me.id)?.ready ? "Я готов ✓" : "Я готов", "ready", !g.voiceConfigured || s.voiceStatus !== "connected" ? "disabled" : "", true)}${g.isOwner ? btn("Начать " + (g.phase === "postgame" ? "новую партию" : "игру"), "start", !g.canStart || !g.voiceConfigured || s.voiceStatus !== "connected" ? "disabled" : "") : ""}${g.phase === "postgame" ? '<button class="text-btn" data-action="history">История предыдущей партии</button>' : ""}</div>`;
  else if (g.phase === "role")
    content = `${timer(s, "На знакомство с ролью")}${roleCard(s)}<div class="actions">${btn(g.me.roleReady ? "Ждём остальных…" : "Роль понятна", "role-ready", !s.revealed || g.me.roleReady ? "disabled" : "")}<p class="small muted center">Когда все подтвердят карты, начнётся знакомство.</p></div>`;
  else if (g.phase === "turn")
    content = `${phaseHead(s, { intro: "Знакомство", main: "Обсуждение", reply: "Короткие ответы", defense: "Защита" }[g.turnKind], g.turnKind === "intro" ? "ПЕРЕД ПЕРВОЙ НОЧЬЮ" : `ДЕНЬ ${String(g.day).padStart(2, "0")}`, g.turnState === "offer" ? "Чтобы принять слово" : "Осталось на речь")}${table(s)}${turnPanel(s)}`;
  else if (g.phase === "night")
    content = `${phaseHead(s, "Город засыпает", `НОЧЬ ${String(g.day).padStart(2, "0")}`, "До рассвета")}${table(s)}${nightPanel(s)}${!g.me.alive ? react(s) : ""}`;
  else if (g.phase === "vote")
    content = `${phaseHead(s, g.runoff ? "Повторный выбор" : "Кому не верите?", `ДЕНЬ ${String(g.day).padStart(2, "0")}`, "На голосование")}${votes(s)}`;
  else if (["dawn", "result"].includes(g.phase))
    content = `${phaseHead(s, g.phase === "dawn" ? "Наступило утро" : "Решение города", `ДЕНЬ ${String(g.day).padStart(2, "0")}`, "До следующей фазы")}<div class="result-scene"><img src="/assets/club-mark.svg" alt=""><h2>${esc(g.result?.text)}</h2><p class="muted">Роли выбывших останутся тайной до финала.</p>${!g.me.alive ? ghost(s) : ""}${g.me.checks?.length ? '<button class="btn secondary" data-action="checks">Мои проверки</button>' : ""}</div>${voteBreakdown(g)}`;
  else if (g.phase === "gameover")
    content = `<div class="eyebrow">МАСКИ СНЯТЫ</div><h1 class="title">${g.winner === "town" ? "Город выстоял." : g.winner === "mafia" ? "Город во тьме." : g.winner === "aborted" ? "Партия прервана." : "Ничья."}</h1><p class="muted">${esc(g.announcement)}</p><div class="result-summary"><span>${time(Math.floor((g.finishedAt - g.startedAt) / 1000))}</span><span>${g.day} ночей</span><span>${(g.winner === "town" && g.me.role !== "mafia") || (g.winner === "mafia" && g.me.role === "mafia") ? "Ваша команда победила" : g.winner === "draw" ? "Без победителя" : "До следующей встречи"}</span></div>${g.technical ? '<p class="small muted">В партии были технические выбывания.</p>' : ""}${reveal(g)}<div class="actions">${btn("Обсудить и сыграть ещё", "postgame")}${btn("История партии", "history", "", true)}</div>`;
  const footer =
    g && !["lobby", "postgame", "role", "gameover"].includes(g.phase)
      ? `<div class="game-footer"><button class="text-btn" data-action="my-role">Моя карта</button><button class="text-btn" data-action="history">История</button>${g.me.role === "detective" ? '<button class="text-btn" data-action="checks">Проверки</button>' : ""}</div>`
      : "";
  return `<section class="screen ${g ? "in-game" : ""}">${header(s)}${s.networkError ? `<div class="notice error" role="status">${esc(s.networkError)} <button class="text-btn" data-action="refresh">Повторить</button></div>` : ""}${content}${footer}${g?.me.needsPresence ? `<div class="presence-check" role="alert"><strong>Вы ещё за столом?</strong>${btn("Да, я здесь", "presence")}</div>` : ""}</section>${s.modal ? modal(s) : ""}${s.toast ? `<div class="toast" role="status">${esc(s.toast)}</div>` : ""}`;
}
function modal(s) {
  const g = s.game;
  let title = "",
    body = "";
  if (s.modal === "rules") {
    title = "Правила клуба";
    body = rulesHTML;
  }
  if (s.modal === "settings") {
    title = "За вашим столом";
    body = `<div class="settings-row"><span>Голос ведущего</span><button class="toggle" data-action="narration" aria-pressed="${s.narration}">${s.narration ? "Вкл" : "Выкл"}</button></div><label class="volume-label">Громкость ведущего<input type="range" min="0" max="1" step="0.05" data-volume="narrator" value="${s.narratorVolume}"></label><label class="volume-label">Громкость игроков<input type="range" min="0" max="1" step="0.05" data-volume="players" value="${s.playerVolume}"></label><div class="settings-row"><span>Атмосфера клуба</span><button class="toggle" data-action="music" aria-pressed="${s.music}">${s.music ? "Вкл" : "Выкл"}</button></div><button class="btn secondary wide" data-action="test-voice">Послушать ведущего</button><p class="small muted">${s.narratorConfigured ? "Ведущий озвучен искусственным голосом. Все объявления дублируются текстом." : "Пока используется голос устройства. Студийная озвучка ещё не подключена."}</p><p class="asset-credit">Эмодзи: <a href="https://github.com/jdecked/twemoji" target="_blank" rel="noopener noreferrer">Twemoji</a> · CC BY 4.0</p><button class="text-btn wide" data-action="check-mic">Проверить микрофон</button>${g ? '<button class="text-btn wide" data-action="retry-voice">Восстановить звук</button>' : ""}<button class="text-btn wide" data-action="rules">Правила игры</button>${g ? '<button class="text-btn danger wide" data-action="leave">Покинуть стол</button>' : ""}`;
  }
  if (s.modal === "mic") {
    title = "Проверка микрофона";
    body = `<p class="muted">Скажите несколько слов. Полоса должна двигаться. Проверка не передаёт звук другим игрокам.</p><div class="audio-test"><span class="mic-meter"></span></div><p class="small">${esc(s.micStatus)}</p>${btn("Разрешить и проверить", "start-mic-test")}${btn("Готово", "close-modal", "", true)}`;
  }
  if (s.modal === "my-role") {
    title = "Ваша тайна";
    body = roleCard(s, true);
  }
  if (s.modal === "checks") {
    title = "Личные проверки";
    body = g.me.checks.length
      ? g.me.checks
          .map(
            (c) =>
              `<div class="check-row"><span>Ночь ${c.day} · ${esc(c.name)}</span><b class="${c.mafia ? "danger" : "gold"}">${c.mafia ? "Мафия" : "Не мафия"}</b></div>`,
          )
          .join("")
      : '<p class="muted">После первой подтверждённой проверки здесь появится результат.</p>';
  }
  if (s.modal === "history") {
    title = "История за столом";
    body = history(g);
  }
  if (s.modal === "leave") {
    title = "Покинуть стол?";
    body = `<p class="muted">${g && !["lobby", "postgame", "gameover"].includes(g.phase) ? "Во время партии это приведёт к вашему выбыванию. Другой игрок не сможет занять ваше место." : "Вы сможете вернуться по коду комнаты, если останется место."}</p>${btn("Остаться", "close-modal")}${btn("Покинуть стол", "confirm-leave", "", true)}`;
  }
  if (s.modal === "player") {
    const p = g.players.find((x) => x.id === s.playerInfo);
    title = esc(p?.name);
    body = `${p ? avatar(p) : ""}<p class="muted">${p?.alive ? "Игрок за столом." : "Игрок выбыл."}</p>${p && p.id !== g.me.id ? btn(s.locallyMuted.includes(p.id) ? "Снова слышать игрока" : "Не слышать этого игрока", "mute-player", "", true) : ""}`;
  }
  return `<div class="menu-backdrop" data-backdrop="true"><div class="menu-sheet" role="dialog" aria-modal="true" aria-labelledby="dialog-title"><div class="row"><h2 id="dialog-title">${title}</h2><button class="iconbtn" data-action="close-modal" aria-label="Закрыть">${icons.close}</button></div>${body}</div></div>`;
}
