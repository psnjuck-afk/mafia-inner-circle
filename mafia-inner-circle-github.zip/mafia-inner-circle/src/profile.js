import { esc } from "./data.js";
const failedPhotos = new Set();
export function avatar(p) {
  let photo = null;
  try {
    const url = new URL(p.photoUrl);
    if (url.protocol === "https:" && !url.username && !url.password && !failedPhotos.has(url.href)) photo = url.href;
  } catch {}
  const initial = Array.from(p.name || "?")[0];
  return `<span class="avatar"><span class="avatar-initial" aria-hidden="true">${esc(initial)}</span>${photo ? `<img class="avatar-photo" src="${esc(photo)}" alt="" referrerpolicy="no-referrer" decoding="async">` : ""}</span>`;
}
export function failedAvatar(image) {
  failedPhotos.add(image.src);
  image.remove();
}
export function profileCard(s) {
  return `<div class="account-profile">${avatar({ name: s.name, photoUrl: s.profile?.photoUrl })}<div><span class="small muted">${s.profile?.source === "telegram" ? "Ваш профиль Telegram" : "За столом"}</span><strong title="${esc(s.name)}">${esc(s.name)}</strong></div></div>`;
}
export function nameField(s) {
  return s.profile?.source === "telegram" ? profileCard(s) : `<label class="field-label" for="nickname">Ваше имя</label><input class="field" id="nickname" maxlength="22" autocomplete="nickname" value="${esc(s.name)}">`;
}
