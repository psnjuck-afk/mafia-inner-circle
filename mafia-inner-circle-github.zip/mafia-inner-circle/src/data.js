export const roles = {
  civilian: {
    name: "Мирный житель",
    description:
      "Слушайте, сопоставляйте версии и найдите мафию на дневном голосовании.",
    hint: "Ночью вы отдыхаете. Ваш главный инструмент — разговор.",
  },
  mafia: {
    name: "Мафия",
    description:
      "Днём убедите город в своей невиновности. Ночью вместе с напарником выберите жертву.",
    hint: "Подтвердите одну общую цель. Разные цели или пропуск означают ночь без убийства.",
  },
  detective: {
    name: "Детектив",
    description:
      "Каждую ночь проверяйте одного игрока: мафия он или нет. Результат известен только вам.",
    hint: "Проверки сохраняются в личных заметках. Точную мирную роль вы не узнаете.",
  },
  doctor: {
    name: "Доктор",
    description:
      "Каждую ночь защищайте одного человека. Если мафия выберет его, он выживет.",
    hint: "Себя можно лечить один раз за партию. Одного человека нельзя лечить две ночи подряд.",
  },
};
export const reactions = ["🤨", "😂", "👀", "😡", "👍", "👎"];
export const composition = (n) => ({
  mafia: n < 8 ? 1 : 2,
  detective: 1,
  doctor: 1,
  civilian: n - (n < 8 ? 3 : 4),
});
export const icons = {
  mic: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 10v2a7 7 0 0 0 14 0v-2M12 19v3m-4 0h8"/></svg>',
  muted:
    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 3 18 18M9 9v3a3 3 0 0 0 5 2M9 5a3 3 0 0 1 6 0v6M5 10v2a7 7 0 0 0 11 6M19 10v2a7 7 0 0 1-1 4M12 19v3m-4 0h8"/></svg>',
  sound:
    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m11 4-6 5H2v6h3l6 5V4zm4 4a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/></svg>',
  close:
    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M6 18 18 6"/></svg>',
  arrow:
    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6"/></svg>',
};
export const esc = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
export const reactionIcon = (emoji) =>
  `<img class="emoji-icon" src="/assets/reactions/${emoji.codePointAt(0).toString(16)}.svg" alt="" draggable="false">`;
