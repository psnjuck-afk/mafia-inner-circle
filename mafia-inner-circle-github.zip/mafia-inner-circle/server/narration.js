// Finite, public lines only: no player names, roles, arbitrary prompts or speech recordings.
export const lines = {
  welcome:
    "Добро пожаловать в клуб. У каждого здесь своя тайна. Посмотрим, кому удастся её сохранить.",
  lobby: "Собираемся за столом. Проверьте звук и подтвердите готовность.",
  role: "Карты розданы. Посмотрите свою роль. Только не выдайте себя.",
  reset: "Не все успели посмотреть карты. Соберёмся и начнём ещё раз.",
  night: "Город засыпает. На ночной ход — одна минута.",
  dawn_safe: "Город просыпается. Этой ночью все выжили.",
  vote: "Время выбирать. Кому вы больше не доверяете?",
  runoff: "Мнения разделились. Голосуем ещё раз.",
  result_safe: "Сегодня никто не покидает стол. Игра продолжается.",
  town: "Город выстоял. Последняя мафия раскрыта. Можно снять маски.",
  mafia: "Город остался во тьме. Мафия победила. Пора раскрыть карты.",
  draw: "Ничья. Сегодня у этой истории нет победителя.",
  aborted: "Партию пришлось прервать. Победителя нет. Соберёмся ещё раз.",
  postgame: "Все маски сняты. Обсудите партию. А потом — сыграем ещё?",
  paused: "Пропала голосовая связь. Даю минуту на восстановление.",
  resumed: "Все снова на связи. Продолжаем.",
};
for (let seat = 1; seat <= 10; seat++) {
  lines[`turn_${seat}`] = `Слово игроку номер ${seat}.`;
  lines[`dawn_${seat}`] =
    `Город просыпается. Игрок номер ${seat} покидает стол.`;
  lines[`result_${seat}`] = `Город решил. Игрок номер ${seat} покидает стол.`;
}
export const narratorConfigured = (env) => Boolean(env.OPENAI_API_KEY);
export function narrationFor(g) {
  const seat = (id) => g.players.findIndex((p) => p.id === id) + 1;
  let key;
  if (g.pausedUntil) key = "paused";
  else if (g.announcement === "Связь восстановлена. Продолжаем партию.")
    key = "resumed";
  else if (g.phase === "lobby")
    key = g.announcement.startsWith("Не все") ? "reset" : "lobby";
  else if (g.phase === "turn") key = `turn_${seat(g.speakerId)}`;
  else if (g.phase === "dawn")
    key = g.result?.killed ? `dawn_${seat(g.result.killed)}` : "dawn_safe";
  else if (g.phase === "result") {
    const counts = g.lastVote?.counts || {};
    const highest = Math.max(0, ...Object.values(counts));
    const leaders = Object.keys(counts).filter((id) => counts[id] === highest);
    const removed =
      leaders.length === 1 &&
      leaders[0] !== "skip" &&
      g.players.find((p) => p.id === leaders[0] && p.death === "vote");
    key = removed ? `result_${seat(removed.id)}` : "result_safe";
  } else if (g.phase === "vote") key = g.runoff ? "runoff" : "vote";
  else if (g.phase === "gameover") key = g.winner;
  else key = g.phase;
  return { key, text: lines[key] || g.announcement };
}
const inflight = new Map();
export async function narrationAudio(env, key, origin) {
  if (!Object.hasOwn(lines, key)) return new Response(null, { status: 404 });
  if (!narratorConfigured(env)) return new Response(null, { status: 503 });
  const cacheKey = new Request(`${origin}/_voice-cache/cedar-v1/${key}.mp3`);
  const cache = globalThis.caches?.default;
  let response = await cache?.match(cacheKey);
  if (!response) {
    const pendingKey = cacheKey.url;
    let pending = inflight.get(pendingKey);
    if (!pending) {
      pending = (async () => {
        const upstream = await fetch("https://api.openai.com/v1/audio/speech", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${env.OPENAI_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "gpt-4o-mini-tts",
            voice: "cedar",
            response_format: "mp3",
            input: lines[key],
            instructions:
              "Speak in natural Russian as a warm, charismatic host of an intimate 1920s speakeasy Mafia game. Calm, confident, conversational, lightly playful. Subtle suspense and expressive intonation. Brief natural pauses, brisk enough for a timed game. No theatrical villain voice, no whispering, no music. Read only the provided line.",
          }),
          signal: AbortSignal.timeout(12000),
        });
        if (!upstream.ok) throw new Error("Narration service unavailable");
        const bytes = await upstream.arrayBuffer();
        const audio = new Response(bytes, {
          headers: {
            "Content-Type": "audio/mpeg",
            "Cache-Control": "public, max-age=31536000",
          },
        });
        try {
          await cache?.put(cacheKey, audio.clone());
        } catch {}
        return audio;
      })();
      inflight.set(pendingKey, pending);
    }
    try {
      response = (await pending).clone();
    } catch {
      return new Response(null, { status: 503 });
    } finally {
      if (inflight.get(pendingKey) === pending) inflight.delete(pendingKey);
    }
  }
  const headers = new Headers(response.headers);
  headers.set("Cache-Control", "private, max-age=86400");
  return new Response(response.body, { headers });
}
