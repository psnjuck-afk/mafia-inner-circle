import { telegramIdentity, cleanName, IdentityError } from "./telegram.js";
// These headers are injected by the authenticated Sites dispatcher.
// Direct/unprotected hosting must provide its own verified identity middleware.
export async function accountId(request) {
  const id = request.headers.get("oai-authenticated-user-id")?.trim();
  if (id) return id;
  // Some deployed Sites dispatchers currently provide verified email without ID.
  // Keep those signed-in visitors usable; never read identity from body/query.
  const email = request.headers.get("oai-authenticated-user-email")?.trim().toLowerCase();
  if (!email || !/^[^\s@]+@[^\s@]+$/.test(email)) return null;
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(new URL(request.url).origin + "\n" + email));
  return "sites-email:" + Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("");
}

export async function identity(request, env) {
  const authorization = request.headers.get("authorization");
  if (authorization) {
    if (!authorization.startsWith("tma ")) throw new IdentityError("Откройте игру заново через Telegram.");
    return telegramIdentity(authorization.slice(4), env.TELEGRAM_BOT_TOKEN);
  }
  // On a standalone server, this mode refuses all client-supplied Sites headers.
  if (env.AUTH_MODE === "telegram") return null;
  const id = await accountId(request);
  if (!id) return null;
  const name = cleanName(request.headers.get("oai-authenticated-user-full-name"));
  return { id, provider: "sites", profile: name ? { name, photoUrl: null, source: "sites" } : null };
}
