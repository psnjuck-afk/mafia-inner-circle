// Telegram Mini App data is authenticated on the server, never via initDataUnsafe.
// https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
const encode = (value) => new TextEncoder().encode(value);
const MAX_AGE_SECONDS = 8 * 60 * 60;
export class IdentityError extends Error {
  constructor(message, status = 401) {
    super(message);
    this.status = status;
  }
}
export const cleanName = (value) => Array.from(String(value || "")
  .replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/g, "")
  .trim()).slice(0, 64).join("");
export function photoUrl(value) {
  if (typeof value !== "string" || value.length > 2048) return null;
  try {
    const url = new URL(value);
    return url.protocol === "https:" && !url.username && !url.password ? url.href : null;
  } catch { return null; }
}
export async function telegramIdentity(raw, botToken, now = Date.now()) {
  if (!botToken) throw new IdentityError("Вход через Telegram ещё настраивается. Попробуйте позже.", 503);
  const invalid = () => new IdentityError("Не удалось подтвердить аккаунт. Откройте игру заново через Telegram.");
  if (typeof raw !== "string" || !raw || raw.length > 12000) throw invalid();
  const params = new URLSearchParams(raw);
  const keys = [...params.keys()];
  if (new Set(keys).size !== keys.length) throw invalid();
  const hash = params.get("hash") || "";
  if (!/^[a-f\d]{64}$/i.test(hash)) throw invalid();
  const authDate = params.get("auth_date") || "";
  const age = Math.floor(now / 1000) - Number(authDate);
  if (!/^\d+$/.test(authDate) || age < -30 || age > MAX_AGE_SECONDS) throw invalid();
  params.delete("hash");
  // The HMAC path includes every remaining field, including signature if supplied.
  const check = [...params].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)
    .map(([key, value]) => `${key}=${value}`).join("\n");
  const root = await crypto.subtle.importKey("raw", encode("WebAppData"), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const secret = await crypto.subtle.sign("HMAC", root, encode(botToken));
  const key = await crypto.subtle.importKey("raw", secret, { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
  const signature = Uint8Array.from(hash.match(/../g), (byte) => parseInt(byte, 16));
  if (!await crypto.subtle.verify("HMAC", key, signature, encode(check))) throw invalid();
  let user;
  try { user = JSON.parse(params.get("user")); } catch { throw invalid(); }
  if (!user || !Number.isSafeInteger(user.id) || user.id <= 0 || typeof user.first_name !== "string") throw invalid();
  return {
    id: `telegram:${user.id}`,
    provider: "telegram",
    authDate: Number(authDate),
    profile: { name: cleanName(user.first_name) || cleanName(user.username) || "Игрок", photoUrl: photoUrl(user.photo_url), source: "telegram" },
  };
}
