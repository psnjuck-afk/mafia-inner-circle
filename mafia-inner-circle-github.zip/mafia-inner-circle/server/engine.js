// Authoritative rules. The browser receives only the current player's view.
export const ROLES = {
  civilian: "Мирный житель",
  mafia: "Мафия",
  detective: "Детектив",
  doctor: "Доктор",
};
export const EMOJI = ["🤨", "😂", "👀", "😡", "👍", "👎"];
export const TIMES = {
  role: 30,
  offer: 10,
  intro: 15,
  main: 40,
  reply: 15,
  defense: 20,
  night: 60,
  vote: 30,
  runoff: 20,
  dawn: 7,
  result: 7,
};
export function composition(n) {
  if (!Number.isInteger(n) || n < 6 || n > 10)
    throw new Error("За столом должно быть от 6 до 10 игроков");
  return {
    mafia: n < 8 ? 1 : 2,
    detective: 1,
    doctor: 1,
    civilian: n - (n < 8 ? 3 : 4),
  };
}
const living = (g) => g.players.filter((p) => p.alive),
  player = (g, id) => g.players.find((p) => p.id === id),
  allReady = (g) =>
    g.players.length === g.seats && g.players.every((p) => p.ready);
export function random(g) {
  g.seed = (Math.imul(g.seed, 1664525) + 1013904223) >>> 0;
  return g.seed / 4294967296;
}
const choose = (g, x) =>
  x.length ? x[Math.floor(random(g) * x.length)] : null;
const shuffle = (g, a) => {
  a = [...a];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(random(g) * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};
const assert = (yes, message) => {
  if (!yes) throw new Error(message);
};
function setPhase(g, phase, now, seconds = 0) {
  g.phase = phase;
  g.phaseSeq++;
  g.phaseStarted = now;
  g.deadline = seconds ? now + seconds * 1000 : null;
  g.botAt = now + 1200;
}
function event(g, type, text, data = {}) {
  g.history.push({ day: g.day, type, text, ...data });
}
function say(g, text) {
  g.announcement = text;
  g.announcementId = (g.announcementId || 0) + 1;
}
export function createPlayer(accountId, name, now, bot = false) {
  return {
    id: crypto.randomUUID(),
    accountId,
    name: name.trim().slice(0, 22) || "Гость",
    bot,
    ready: bot,
    alive: true,
    lastSeen: now,
    checks: [],
    lastHeal: null,
    selfHealUsed: false,
    missed: 0,
  };
}
export function createGame({
  code,
  ownerId,
  name,
  seats = 8,
  mode = "private",
  now = Date.now(),
  seed,
  trainingRole = "random",
}) {
  composition(seats);
  const p = createPlayer(ownerId, name, now);
  const g = {
    code,
    ownerId,
    mode,
    seats,
    seed: seed ?? crypto.getRandomValues(new Uint32Array(1))[0],
    trainingRole,
    players: [p],
    phase: "lobby",
    phaseSeq: 1,
    day: 0,
    match: 0,
    matchId: crypto.randomUUID(),
    phaseStarted: now,
    deadline: null,
    history: [],
    announcement: "Собираемся за столом",
    announcementId: 1,
    reactions: [],
    processed: [],
    winner: null,
    technical: false,
  };
  if (mode === "training") {
    const names = [
      "Алиса",
      "Марк",
      "Соня",
      "Лев",
      "Дина",
      "Тимур",
      "Ника",
      "Олег",
      "Рита",
    ];
    for (let i = 1; i < seats; i++)
      g.players.push(createPlayer("bot:" + i, names[i - 1], now, true));
  }
  return g;
}
export function joinGame(g, accountId, name, now) {
  const p = g.players.find((p) => p.accountId === accountId);
  if (p) {
    p.lastSeen = now;
    return p;
  }
  assert(
    ["lobby", "postgame"].includes(g.phase),
    "Партия уже идёт. Дождитесь следующей игры",
  );
  assert(g.players.length < g.seats, "За столом нет свободных мест");
  const added = createPlayer(accountId, name, now);
  g.players.push(added);
  return added;
}
function start(g, now) {
  let roles = shuffle(
    g,
    Object.entries(composition(g.seats)).flatMap(([role, n]) =>
      Array(n).fill(role),
    ),
  );
  if (g.mode === "training" && g.trainingRole !== "random") {
    const i = roles.indexOf(g.trainingRole);
    [roles[0], roles[i]] = [roles[i], roles[0]];
  }
  g.voiceFailures = {};
  g.pausedUntil = null;
  g.match++;
  g.matchId = crypto.randomUUID();
  g.day = 0;
  g.history = [];
  g.winner = null;
  g.technical = false;
  g.runoff = false;
  g.reactions = [];
  g.firstSpeaker = Math.floor(random(g) * g.seats);
  g.startedAt = now;
  g.lastVote = null;
  g.result = null;
  g.votes = {};
  g.players.forEach((p, i) =>
    Object.assign(p, {
      role: roles[i],
      alive: true,
      roleReady: p.bot,
      checks: [],
      lastHeal: null,
      selfHealUsed: false,
      nightChoice: undefined,
      missed: 0,
      replySkipped: false,
      departed: false,
      pendingLeave: false,
      needsPresence: false,
      pendingRemoval: false,
      lastSeen: now,
    }),
  );
  setPhase(g, "role", now, TIMES.role);
  say(g, "Карты розданы. Посмотрите свою роль.");
}
function cancelStart(g, now) {
  g.players.forEach((p) => {
    p.ready = p.bot;
    delete p.role;
    p.roleReady = false;
  });
  setPhase(g, "lobby", now);
  say(g, "Не все подтвердили карты. Подготовьте стол и начните заново.");
}
function order(g, ids = living(g).map((p) => p.id)) {
  return g.players
    .slice(g.firstSpeaker)
    .concat(g.players.slice(0, g.firstSpeaker))
    .filter((p) => ids.includes(p.id))
    .map((p) => p.id);
}
function beginRound(g, kind, now, ids) {
  g.turnKind = kind;
  g.queue = order(g, ids);
  g.turnIndex = -1;
  nextTurn(g, now);
}
function nextTurn(g, now) {
  settleDepartures(g, now);
  if (g.day > 0 && checkWin(g, now)) return;
  do {
    g.turnIndex++;
  } while (
    g.turnIndex < g.queue.length &&
    (!player(g, g.queue[g.turnIndex])?.alive ||
      (g.turnKind === "reply" && player(g, g.queue[g.turnIndex]).replySkipped))
  );
  if (g.turnIndex >= g.queue.length) {
    if (g.turnKind === "intro") beginNight(g, now);
    else if (g.turnKind === "main") beginRound(g, "reply", now);
    else if (g.turnKind === "reply") beginVote(g, now, false);
    else beginVote(g, now, true);
    return;
  }
  g.speakerId = g.queue[g.turnIndex];
  g.turnState = "offer";
  setPhase(g, "turn", now, TIMES.offer);
  say(
    g,
    `Слово игроку номер ${g.players.findIndex((p) => p.id === g.speakerId) + 1}.`,
  );
}
function acceptTurn(g, p, now) {
  assert(
    p.id === g.speakerId && g.turnState === "offer",
    "Сейчас слово у другого игрока",
  );
  g.turnState = "speaking";
  p.missed = 0;
  setPhase(g, "turn", now, TIMES[g.turnKind]);
  g.botAt = now + Math.min(7000, TIMES[g.turnKind] * 1000);
}
function beginNight(g, now) {
  g.day++;
  g.players.forEach((p) => {
    p.nightChoice = undefined;
    p.replySkipped = false;
  });
  g.nightIds = living(g).map((p) => p.id);
  g.mafiaBotTarget = null;
  setPhase(g, "night", now, TIMES.night);
  say(g, `Ночь ${g.day}. Город засыпает. На ночной ход — одна минута.`);
}
export function targets(g, p) {
  const alive = living(g);
  if (g.phase === "night") {
    if (p.role === "mafia")
      return alive.filter((x) => x.role !== "mafia").map((x) => x.id);
    if (p.role === "detective")
      return alive.filter((x) => x.id !== p.id).map((x) => x.id);
    if (p.role === "doctor")
      return alive
        .filter(
          (x) => x.id !== p.lastHeal && (x.id !== p.id || !p.selfHealUsed),
        )
        .map((x) => x.id);
    return [];
  }
  if (g.phase === "vote")
    return alive
      .filter((x) => x.id !== p.id && (!g.runoff || g.nominees.includes(x.id)))
      .map((x) => x.id);
  return [];
}
function resolveNight(g, now) {
  const active = g.players.filter((p) => g.nightIds.includes(p.id)),
    maf = active.filter((p) => p.role === "mafia"),
    choices = maf.map((p) => p.nightChoice);
  const victim =
    choices.length &&
    choices.every((x) => x && x !== "skip" && x === choices[0])
      ? choices[0]
      : null;
  const doctor = active.find((p) => p.role === "doctor"),
    heal = doctor?.nightChoice;
  if (heal && heal !== "skip") {
    doctor.lastHeal = heal;
    if (heal === doctor.id) doctor.selfHealUsed = true;
  } else if (doctor) doctor.lastHeal = null;
  const detective = active.find((p) => p.role === "detective");
  let check = null;
  if (detective?.nightChoice && detective.nightChoice !== "skip") {
    const target = player(g, detective.nightChoice);
    check = {
      day: g.day,
      id: target.id,
      name: target.name,
      mafia: target.role === "mafia",
    };
    detective.checks.push(check);
  }
  const saved = victim && victim === heal,
    killed = victim && !saved ? player(g, victim) : null;
  if (killed) {
    killed.alive = false;
    killed.death = "night";
  }
  const text = killed
    ? `Город просыпается. ${killed.name} покидает стол.`
    : "Город просыпается. Этой ночью все выжили.";
  event(g, "night", text, {
    mafiaTarget: victim,
    mafiaChoices: maf.map((p) => ({
      id: p.id,
      target: p.nightChoice ?? "timeout",
    })),
    heal: heal ?? null,
    check,
    killed: killed?.id ?? null,
    saved: Boolean(saved),
  });
  g.result = { text, killed: killed?.id ?? null };
  settleDepartures(g, now);
  if (checkWin(g, now)) return;
  setPhase(g, "dawn", now, TIMES.dawn);
  say(g, text);
}
function beginVote(g, now, runoff) {
  g.runoff = runoff;
  g.votes = {};
  g.voteIds = living(g).map((p) => p.id);
  setPhase(g, "vote", now, runoff ? TIMES.runoff : TIMES.vote);
  say(
    g,
    runoff
      ? "Повторное голосование. Выберите одного из кандидатов."
      : "Голосование. Кому вы не доверяете?",
  );
}
export function tally(votes) {
  const counts = { skip: 0 };
  for (const target of Object.values(votes))
    counts[target] = (counts[target] || 0) + 1;
  const max = Math.max(...Object.values(counts));
  return {
    counts,
    leaders: Object.keys(counts).filter((id) => counts[id] === max),
  };
}
function resolveVote(g, now) {
  for (const id of g.voteIds)
    if (!g.votes[id]) {
      g.votes[id] = "skip";
      const p = player(g, id);
      p.missed++;
      if (p.missed >= 2) p.needsPresence = now + 20000;
    }
  const { counts, leaders } = tally(g.votes);
  g.lastVote = { votes: { ...g.votes }, counts, runoff: g.runoff };
  event(g, "vote", g.runoff ? "Повторное голосование" : "Голосование", {
    votes: { ...g.votes },
    counts,
  });
  let text = "Сегодня никто не покидает стол.";
  settleDepartures(g, now);
  if (checkWin(g, now)) return;
  if (!leaders.includes("skip") && leaders.length > 1 && !g.runoff) {
    g.nominees = leaders.filter((id) => player(g, id)?.alive);
    if (g.nominees.length > 1) {
      beginRound(g, "defense", now, g.nominees);
      return;
    }
  }
  if (!leaders.includes("skip") && leaders.length === 1) {
    const p = player(g, leaders[0]);
    if (p?.alive) {
      p.alive = false;
      p.death = "vote";
      text = `Решение города: ${p.name} покидает стол.`;
      event(g, "elimination", text, { id: p.id });
    }
  }
  g.result = { text };
  if (checkWin(g, now)) return;
  if (g.day >= 10) {
    finish(g, "draw", now, "Десятый день завершён. Партия закончилась ничьей.");
    return;
  }
  setPhase(g, "result", now, TIMES.result);
  say(g, text);
}
function finish(g, winner, now, text) {
  g.winner = winner;
  g.finishedAt = now;
  g.players.forEach((p) => {
    p.ready = p.bot;
  });
  setPhase(g, "gameover", now);
  say(g, text);
}
export function checkWin(g, now) {
  const alive = living(g),
    mafia = alive.filter((p) => p.role === "mafia").length;
  if (!alive.length) {
    finish(g, "draw", now, "За столом не осталось игроков. Ничья.");
    return true;
  }
  if (mafia === 0) {
    finish(g, "town", now, "Город выстоял. Последняя мафия раскрыта.");
    return true;
  }
  if (mafia >= alive.length - mafia) {
    finish(g, "mafia", now, "Мафия захватила город. Партия окончена.");
    return true;
  }
  return false;
}
function settleDepartures(g, now) {
  if (["lobby", "postgame", "role", "gameover"].includes(g.phase)) return;
  for (const p of living(g))
    if (
      p.pendingLeave ||
      p.pendingRemoval ||
      (g.mode !== "training" && !p.bot && now - p.lastSeen >= 60000) ||
      (p.needsPresence && now >= p.needsPresence)
    ) {
      p.alive = false;
      p.departed = true;
      p.death = "technical";
      g.technical = true;
      event(
        g,
        "technical",
        `${p.name} выбыл из-за выхода или отсутствия связи.`,
        { id: p.id },
      );
    }
}
function botActions(g, now) {
  if (now < g.botAt) return;
  if (g.phase === "turn") {
    const p = player(g, g.speakerId);
    if (p?.bot) {
      if (g.turnState === "offer") acceptTurn(g, p, g.botAt);
      else nextTurn(g, g.botAt);
    }
  }
  if (g.phase === "night") {
    const bots = living(g).filter((p) => p.bot),
      firstMafia = living(g).find((p) => p.role === "mafia");
    if (!g.mafiaBotTarget && firstMafia)
      g.mafiaBotTarget = choose(g, targets(g, firstMafia));
    for (const p of bots) {
      if (p.nightChoice !== undefined || p.role === "civilian") continue;
      let options = targets(g, p);
      if (p.role === "detective") {
        const fresh = options.filter(
          (id) => !p.checks.some((c) => c.id === id),
        );
        if (fresh.length) options = fresh;
      }
      p.nightChoice =
        p.role === "mafia"
          ? living(g).find((x) => x.role === "mafia" && !x.bot)?.nightChoice ||
            g.mafiaBotTarget ||
            "skip"
          : choose(g, options) || "skip";
    }
    const human = living(g).find(
      (p) => p.role === "mafia" && !p.bot && p.nightChoice !== undefined,
    );
    if (human)
      for (const p of bots.filter((p) => p.role === "mafia"))
        p.nightChoice = human.nightChoice;
  }
  if (g.phase === "vote")
    for (const p of living(g).filter((p) => p.bot && !g.votes[p.id])) {
      let options = targets(g, p);
      if (p.role === "mafia")
        options = options.filter((id) => player(g, id).role !== "mafia");
      const known = p.checks.find((c) => c.mafia && options.includes(c.id));
      g.votes[p.id] = known?.id ?? choose(g, options) ?? "skip";
    }
}
export function tick(g, now = Date.now()) {
  if (["lobby", "postgame"].includes(g.phase)) {
    g.players = g.players.filter(
      (p) =>
        !p.pendingLeave &&
        !p.departed &&
        (p.bot || g.mode === "training" || now - p.lastSeen < 60000),
    );
    if (!g.players.some((p) => p.accountId === g.ownerId))
      g.ownerId = g.players.find((p) => !p.bot)?.accountId ?? null;
  }
  if (g.pausedUntil) {
    if (now >= g.pausedUntil) {
      g.pausedUntil = null;
      finish(
        g,
        "aborted",
        now,
        "Звук не удалось восстановить. Партия завершена без победителя.",
      );
    }
    return g;
  }
  if (
    g.mode !== "training" &&
    !["lobby", "postgame", "gameover", "role"].includes(g.phase)
  )
    for (const p of living(g))
      if (!p.bot && now - p.lastSeen >= 60000) p.pendingRemoval = true;
  for (let guard = 0; guard < 128; guard++) {
    const phase = g.phase,
      seq = g.phaseSeq;
    if (phase === "lobby" && g.mode === "quick" && allReady(g)) {
      start(g, now);
      continue;
    }
    if (phase === "role" && g.players.every((p) => p.roleReady)) {
      beginRound(g, "intro", now);
      continue;
    }
    botActions(g, now);
    if (seq !== g.phaseSeq) continue;
    if (phase === "vote" && g.voteIds.every((id) => g.votes[id])) {
      resolveVote(g, now);
      continue;
    }
    if (!g.deadline || now < g.deadline) break;
    const boundary = g.deadline;
    if (phase === "role") cancelStart(g, boundary);
    else if (phase === "turn") {
      const p = player(g, g.speakerId);
      if (g.turnState === "offer" && !p.bot) {
        p.missed++;
        if (p.missed >= 2) p.needsPresence = now + 20000;
      }
      nextTurn(g, boundary);
    } else if (phase === "night") resolveNight(g, boundary);
    else if (phase === "dawn") {
      g.firstSpeaker = (g.firstSpeaker + 1) % g.seats;
      beginRound(g, "main", boundary);
    } else if (phase === "vote") resolveVote(g, boundary);
    else if (phase === "result") beginNight(g, boundary);
    else break;
  }
  return g;
}
export function command(g, accountId, cmd, now = Date.now()) {
  const p = g.players.find((p) => p.accountId === accountId);
  assert(p, "Вы не за этим столом");
  if (cmd.eventId && g.processed.includes(accountId + cmd.eventId)) return;
  tick(g, now);
  p.lastSeen = now;
  assert(!p.pendingLeave || cmd.type === "leave", "Вы уже покинули партию");
  assert(
    !g.pausedUntil ||
      ["voice_error", "voice_ok", "presence", "leave"].includes(cmd.type),
    "Идёт техническая пауза",
  );
  if (
    cmd.phaseSeq !== undefined &&
    ![
      "leave",
      "presence",
      "react",
      "ready",
      "postgame",
      "voice_error",
      "voice_ok",
    ].includes(cmd.type)
  )
    assert(cmd.phaseSeq === g.phaseSeq, "Фаза уже сменилась. Обновляем стол");
  if (["voice_error", "voice_ok"].includes(cmd.type)) {
    assert(g.mode !== "training", "В тренировке нет общего голосового канала");
    g.voiceFailures ??= {};
    if (cmd.type === "voice_error") g.voiceFailures[p.id] = now;
    else delete g.voiceFailures[p.id];
    const count = living(g).filter(
      (x) =>
        g.voiceFailures[x.id] &&
        (g.pausedUntil || now - g.voiceFailures[x.id] < 30000),
    ).length;
    if (
      !g.pausedUntil &&
      count >= Math.max(2, Math.ceil(living(g).length / 2)) &&
      !["lobby", "postgame", "gameover"].includes(g.phase)
    ) {
      g.pauseStarted = now;
      g.pausedUntil = now + 60000;
      say(g, "Проблема с голосовой связью. Техническая пауза — одна минута.");
    } else if (
      g.pausedUntil &&
      cmd.type === "voice_ok" &&
      count < Math.max(2, Math.ceil(living(g).length / 2))
    ) {
      const elapsed = now - g.pauseStarted;
      if (g.deadline) g.deadline += elapsed;
      g.botAt += elapsed;
      g.pausedUntil = null;
      say(g, "Связь восстановлена. Продолжаем партию.");
    }
  } else if (cmd.type === "ready") {
    assert(["lobby", "postgame"].includes(g.phase), "Партия уже началась");
    p.ready = !p.ready;
  } else if (cmd.type === "start") {
    assert(g.ownerId === accountId, "Игру запускает создатель комнаты");
    assert(
      ["lobby", "postgame"].includes(g.phase) && allReady(g),
      "Все места должны быть заняты готовыми игроками",
    );
    start(g, now);
  } else if (cmd.type === "role_ready") {
    assert(g.phase === "role", "Карты уже подтверждены");
    p.roleReady = true;
  } else if (cmd.type === "speak") {
    assert(g.phase === "turn" && p.alive, "Сейчас нельзя говорить");
    acceptTurn(g, p, now);
  } else if (cmd.type === "pass") {
    assert(
      g.phase === "turn" && p.id === g.speakerId && p.alive,
      "Сейчас слово у другого игрока",
    );
    p.missed = 0;
    nextTurn(g, now);
  } else if (cmd.type === "skip_reply") {
    assert(
      p.alive && g.phase === "turn" && ["main", "reply"].includes(g.turnKind),
      "Круг ответов недоступен",
    );
    p.replySkipped = !p.replySkipped;
    if (g.turnKind === "reply" && p.id === g.speakerId && p.replySkipped)
      nextTurn(g, now);
  } else if (cmd.type === "night") {
    assert(
      g.phase === "night" && p.alive && p.role !== "civilian",
      "Ночное действие недоступно",
    );
    assert(
      cmd.target === "skip" || targets(g, p).includes(cmd.target),
      "Этого игрока нельзя выбрать",
    );
    p.nightChoice = cmd.target;
    p.missed = 0;
  } else if (cmd.type === "vote") {
    assert(
      g.phase === "vote" && g.voteIds.includes(p.id) && p.alive,
      "Сейчас нельзя голосовать",
    );
    assert(!g.votes[p.id], "Голос уже принят");
    assert(
      cmd.target === "skip" || targets(g, p).includes(cmd.target),
      "Этого игрока нельзя выбрать",
    );
    g.votes[p.id] = cmd.target;
    p.missed = 0;
  } else if (cmd.type === "react") {
    assert(
      g.phase === "turn" ||
        (!p.alive && !["gameover", "postgame", "lobby"].includes(g.phase)),
      "Реакции сейчас недоступны",
    );
    assert(EMOJI.includes(cmd.emoji), "Неизвестная реакция");
    assert(
      !p.lastReaction || now - p.lastReaction >= 2000,
      "Подождите пару секунд",
    );
    p.lastReaction = now;
    g.reactions.push({
      id: p.id,
      emoji: cmd.emoji,
      ghost: !p.alive,
      until: now + 2400,
    });
    g.reactions = g.reactions.filter((x) => x.until > now).slice(-20);
  } else if (cmd.type === "presence") {
    p.needsPresence = false;
    p.missed = 0;
  } else if (cmd.type === "postgame") {
    assert(
      ["gameover", "postgame"].includes(g.phase),
      "Партия ещё продолжается",
    );
    if (g.phase !== "postgame") {
      g.players = g.players.filter(
        (x) => !x.departed || x.accountId === accountId,
      );
      p.departed = false;
      p.pendingRemoval = false;
      g.seats = Math.max(6, g.players.length);
      setPhase(g, "postgame", now);
      say(g, "Маски сняты. Обсудите партию и подготовьтесь к реваншу.");
    }
  } else if (cmd.type === "leave") {
    if (["lobby", "postgame"].includes(g.phase))
      g.players = g.players.filter((x) => x.id !== p.id);
    else {
      p.pendingLeave = true;
      p.departed = true;
      if (g.phase === "role") cancelStart(g, now);
    }
    if (g.ownerId === accountId)
      g.ownerId =
        g.players.find((x) => !x.bot && !x.departed)?.accountId ?? null;
  } else if (cmd.type === "training_next") {
    assert(
      g.mode === "training" && g.ownerId === accountId,
      "Доступно только в тренировке",
    );
    if (g.phase === "night" || g.phase === "vote")
      botActions(g, Math.max(now, g.botAt));
    if (g.deadline) {
      g.deadline = now;
      if (g.phase === "turn" && player(g, g.speakerId)?.bot) g.botAt = now;
    }
    tick(g, now);
  } else throw new Error("Неизвестное действие");
  if (cmd.eventId)
    g.processed = [...g.processed, accountId + cmd.eventId].slice(-60);
  tick(g, now);
}
export function voiceAccess(g, p) {
  if (p.pendingLeave) return { channel: "silent", publish: false, rooms: [] };
  const prefix = `mafia-${g.matchId}-${g.phaseSeq}`;
  if (g.mode === "training")
    return { channel: "training", publish: false, rooms: [] };
  if (["lobby", "postgame", "gameover"].includes(g.phase))
    return {
      channel: "table",
      publish: true,
      rooms: [{ name: prefix + "-table", publish: true }],
    };
  const rooms = [];
  if (!p.alive) rooms.push({ name: prefix + "-ghost", publish: true });
  if (g.phase === "turn")
    rooms.push({
      name: prefix + "-day",
      publish: p.alive && g.speakerId === p.id && g.turnState === "speaking",
    });
  if (g.phase === "night" && p.alive && p.role === "mafia")
    rooms.push({ name: prefix + "-mafia", publish: true });
  return {
    channel: !p.alive
      ? "ghost"
      : g.phase === "night" && p.role === "mafia"
        ? "mafia"
        : g.phase === "turn"
          ? "day"
          : "silent",
    publish: rooms.some((r) => r.publish),
    rooms,
  };
}
export function view(g, accountId, now = Date.now()) {
  const me = g.players.find((p) => p.accountId === accountId);
  assert(me, "Вы не за этим столом");
  const ended = ["gameover", "postgame"].includes(g.phase),
    mafia = me.role === "mafia";
  const publicHistory = g.history.map((e) =>
    ended
      ? e
      : e.type === "night"
        ? { day: e.day, type: e.type, text: e.text, killed: e.killed }
        : e,
  );
  return {
    code: g.code,
    mode: g.mode,
    seats: g.seats,
    composition: composition(g.seats),
    phase: g.phase,
    phaseSeq: g.phaseSeq,
    phaseStarted: g.phaseStarted,
    deadline: g.pausedUntil || g.deadline,
    pausedUntil: g.pausedUntil,
    serverNow: now,
    day: g.day,
    match: g.match,
    matchId: g.matchId,
    winner: g.winner,
    technical: g.technical,
    startedAt: g.startedAt,
    finishedAt: g.finishedAt,
    announcement: g.announcement,
    announcementId: g.announcementId,
    result: g.result,
    turnKind: g.turnKind,
    turnState: g.turnState,
    speakerId: g.speakerId,
    queue: g.queue,
    turnIndex: g.turnIndex,
    runoff: g.runoff,
    nominees: g.nominees,
    lastVote: g.lastVote,
    history: publicHistory,
    reactions: g.reactions.filter(
      (r) => r.until > now && (me.alive ? !r.ghost : true),
    ),
    canStart: g.ownerId === accountId && allReady(g),
    isOwner: g.ownerId === accountId,
    players: g.players.map((p) => ({
      id: p.id,
      name: p.name,
      photoUrl: p.photoUrl || null,
      bot: p.bot,
      alive: p.alive,
      ready: p.ready,
      departed: p.departed,
      role: ended ? p.role : undefined,
      connected: p.bot || now - p.lastSeen < 15000,
    })),
    me: {
      id: me.id,
      name: me.name,
      photoUrl: me.photoUrl || null,
      alive: me.alive,
      role: me.role,
      roleReady: me.roleReady,
      checks: me.checks,
      allies: mafia
        ? g.players
            .filter((p) => p.role === "mafia" && p.id !== me.id)
            .map((p) => p.id)
        : [],
      nightChoice: me.nightChoice,
      teammateChoices:
        mafia && me.alive && g.phase === "night"
          ? g.players
              .filter((p) => p.role === "mafia" && p.alive && p.id !== me.id)
              .map((p) => ({ id: p.id, choice: p.nightChoice }))
          : [],
      vote: g.votes?.[me.id],
      selfHealUsed: me.selfHealUsed,
      lastHeal: me.lastHeal,
      targets: me.alive ? targets(g, me) : [],
      replySkipped: me.replySkipped,
      needsPresence: me.needsPresence,
      departed: me.departed,
    },
    votesCast: g.phase === "vote" ? Object.keys(g.votes).length : 0,
    voice: voiceAccess(g, me),
  };
}
