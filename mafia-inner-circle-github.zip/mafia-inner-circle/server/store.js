export async function load(db, code) {
  const row = await db
    .prepare("SELECT state, version FROM rooms WHERE code = ?")
    .bind(code)
    .first();
  if (!row) throw new Error("Комната не найдена. Проверьте код");
  return { ...row, game: JSON.parse(row.state) };
}
export async function insert(db, g, now) {
  await db
    .prepare(
      "INSERT INTO rooms (code,state,version,mode,phase,seats,count,updated) VALUES (?,?,0,?,?,?,?,?)",
    )
    .bind(
      g.code,
      JSON.stringify(g),
      g.mode,
      g.phase,
      g.seats,
      g.players.length,
      now,
    )
    .run();
}
// Optimistic compare-and-swap prevents two clients from resolving a phase twice.
export async function mutate(db, code, fn, now) {
  for (let i = 0; i < 6; i++) {
    const { game, version, state } = await load(db, code);
    const before = structuredClone(game);
    await fn(game);
    const next = JSON.stringify(game);
    if (next === state) return { game, before };
    const r = await db
      .prepare(
        "UPDATE rooms SET state=?,version=version+1,phase=?,count=?,updated=? WHERE code=? AND version=?",
      )
      .bind(next, game.phase, game.players.length, now, code, version)
      .run();
    if (r.meta.changes === 1) return { game, before };
  }
  throw new Error("Стол обновляется. Повторите действие");
}
export async function membership(db, id) {
  return db
    .prepare("SELECT code FROM members WHERE account=?")
    .bind(id)
    .first();
}
export async function remember(db, id, code, now) {
  await db
    .prepare(
      "INSERT INTO members (account,code,updated) VALUES (?,?,?) ON CONFLICT(account) DO UPDATE SET code=excluded.code,updated=excluded.updated",
    )
    .bind(id, code, now)
    .run();
}
