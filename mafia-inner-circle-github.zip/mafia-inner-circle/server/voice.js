export const configured = (env) =>
  Boolean(
    /^wss:\/\/[^/\s]+\/?$/.test(env.LIVEKIT_URL || "") &&
      env.LIVEKIT_API_KEY &&
      env.LIVEKIT_API_SECRET,
  );
const base64 = (bytes) =>
  btoa(String.fromCharCode(...bytes))
    .replace(/=/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");
const encode = (x) => base64(new TextEncoder().encode(JSON.stringify(x)));
export async function token(env, identity, name, video) {
  const now = Math.floor(Date.now() / 1000),
    data =
      encode({ alg: "HS256", typ: "JWT" }) +
      "." +
      encode({
        iss: env.LIVEKIT_API_KEY,
        sub: identity,
        name,
        nbf: now - 5,
        exp: now + 30,
        video,
      });
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(env.LIVEKIT_API_SECRET),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return (
    data +
    "." +
    base64(
      new Uint8Array(
        await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(data)),
      ),
    )
  );
}
export async function closeRooms(env, names) {
  if (!configured(env)) return;
  await Promise.allSettled(
    [...new Set(names)].map(async (room) => {
      const jwt = await token(env, "game-server", "Ведущий", {
        roomCreate: true,
      });
      const url =
        env.LIVEKIT_URL.replace(/^ws/, "http").replace(/\/$/, "") +
        "/twirp/livekit.RoomService/DeleteRoom";
      const r = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: "Bearer " + jwt,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ room }),
        signal: AbortSignal.timeout(5000),
      });
      if (!r.ok && r.status !== 404)
        console.error("Voice room cleanup failed", r.status);
    }),
  );
}

// Verify credentials against the service before accepting readiness/start.
// A short cache avoids one management API call per player.
let health;
export async function checkService(env) {
  if (!configured(env)) throw new Error("Голосовой сервис ещё не подключён");
  const fingerprint = [
    env.LIVEKIT_URL,
    env.LIVEKIT_API_KEY,
    env.LIVEKIT_API_SECRET,
  ].join("\n");
  if (health?.fingerprint === fingerprint && health.until > Date.now())
    return health.promise;
  const entry = { fingerprint, until: Date.now() + 15000 };
  entry.promise = (async () => {
    const jwt = await token(env, "game-server", "Ведущий", { roomList: true });
    const response = await fetch(
      env.LIVEKIT_URL.replace(/^ws/, "http").replace(/\/$/, "") +
        "/twirp/livekit.RoomService/ListRooms",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${jwt}`,
          "Content-Type": "application/json",
        },
        body: "{}",
        signal: AbortSignal.timeout(5000),
      },
    );
    if (!response.ok)
      throw new Error("Голосовая связь пока недоступна. Повторите чуть позже.");
    return true;
  })().catch(() => {
    if (health === entry) health = null;
    throw new Error("Голосовая связь пока недоступна. Повторите чуть позже.");
  });
  health = entry;
  return entry.promise;
}
