import {
  createGame,
  joinGame,
  command,
  tick,
  view,
  voiceAccess,
  composition,
} from "./engine.js";
import { identity } from "./identity.js";
import { IdentityError } from "./telegram.js";
import { load, insert, mutate, membership, remember } from "./store.js";
import { configured, token, closeRooms, checkService } from "./voice.js";
import {
  narratorConfigured,
  narrationFor,
  narrationAudio,
} from "./narration.js";
const json = (x, status = 200) =>
  new Response(JSON.stringify(x), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
    },
  });
const publicView = (g, id, env, now) => ({
  ...view(g, id, now),
  voiceConfigured: configured(env),
  narratorConfigured: narratorConfigured(env),
  narration: narrationFor(g),
});
async function body(req) {
  const s = await req.text();
  if (s.length > 12000) throw new Error("Слишком большой запрос");
  return s ? JSON.parse(s) : {};
}
const newCode = () =>
  Array.from(
    crypto.getRandomValues(new Uint8Array(6)),
    (x) => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[x % 31],
  ).join("");
function closePrevious(before, game, env, ctx) {
  if (before.phaseSeq === game.phaseSeq) return;
  ctx.waitUntil(
    closeRooms(
      env,
      before.players.flatMap((p) =>
        voiceAccess(before, p).rooms.map((r) => r.name),
      ),
    ),
  );
}
export default {
  async fetch(req, env, ctx) {
    const url = new URL(req.url);
    if (!url.pathname.startsWith("/api/")) return env.ASSETS.fetch(req);
    try {
      const account = await identity(req, env);
      const id = account?.id;
      if (!id)
        return json({ error: env.AUTH_MODE === "telegram" ? "Откройте игру через Telegram, чтобы сесть за стол." : "Войдите в аккаунт, чтобы сесть за стол" }, 401);
      if (!env.DB)
        return json(
          { error: "Столы временно недоступны. Попробуйте позже" },
          503,
        );
      if (
        req.method !== "GET" &&
        req.headers.get("origin") &&
        req.headers.get("origin") !== url.origin
      )
        return json({ error: "Запрос с другого сайта отклонён" }, 403);
      const now = Date.now(),
        path = url.pathname;
      const data = req.method === "POST" ? await body(req) : {};
      const playerName = account.provider === "telegram" ? account.profile.name : String(data.name || account.profile?.name || "Гость");
      const syncProfile = (p) => {
        if (p && account.provider === "telegram" && (!p.profileAuthDate || account.authDate >= p.profileAuthDate)) {
          p.name = account.profile.name;
          p.photoUrl = account.profile.photoUrl;
          p.profileAuthDate = account.authDate;
        }
        return p;
      };
      if (path === "/api/session" && req.method === "GET") {
        let current = await membership(env.DB, id);
        if (current) {
          try {
            const { game } = await load(env.DB, current.code);
            if (
              game.mode === "training" ||
              !game.players.some((p) => p.accountId === id && !p.pendingLeave)
            ) {
              await env.DB.prepare("DELETE FROM members WHERE account=?")
                .bind(id)
                .run();
              current = null;
            }
          } catch {
            await env.DB.prepare("DELETE FROM members WHERE account=?")
              .bind(id)
              .run();
            current = null;
          }
        }
        return json({
          profile: account.profile,
          room: current?.code ?? null,
          voiceConfigured: configured(env),
          narratorConfigured: narratorConfigured(env),
        });
      }
      if (path === "/api/rooms" && req.method === "POST") {
        if (data.mode === "training")
          return json(
            {
              error:
                "Тренировка отключена. Выберите игру с друзьями или поиск стола.",
            },
            410,
          );
        if (
          data.mode !== undefined &&
          !["private", "quick"].includes(data.mode)
        )
          throw new Error("Неизвестный режим игры");
        const mode = data.mode ?? "private",
          seats = Number(data.seats);
        composition(seats);
        const old = await membership(env.DB, id);
        if (old) {
          const { game } = await load(env.DB, old.code);
          const p = game.players.find((p) => p.accountId === id);
          if (game.mode !== "training" && p && !p.departed)
            return json(
              { error: "Сначала покиньте текущий стол", room: old.code },
              409,
            );
        }
        if (mode === "quick") {
          const candidates = await env.DB.prepare(
            "SELECT code FROM rooms WHERE mode='quick' AND phase='lobby' AND seats=? AND count<seats AND updated>? ORDER BY updated LIMIT 5",
          )
            .bind(seats, now - 120000)
            .all();
          for (const candidate of candidates.results) {
            try {
              const { game } = await mutate(
                env.DB,
                candidate.code,
                (g) => syncProfile(joinGame(g, id, playerName, now)),
                now,
              );
              await remember(env.DB, id, game.code, now);
              return json(publicView(game, id, env, now));
            } catch {}
          }
        }
        const g = createGame({
          code: newCode(),
          ownerId: id,
          name: playerName,
          mode,
          seats,
          now,
        });
        syncProfile(g.players[0]);
        await insert(env.DB, g, now);
        await remember(env.DB, id, g.code, now);
        return json(publicView(g, id, env, now));
      }
      if (path === "/api/join" && req.method === "POST") {
        const code = String(data.code || "")
          .trim()
          .toUpperCase();
        if (!/^[A-Z2-9]{6}$/.test(code))
          throw new Error("Введите код из шести символов");
        const old = await membership(env.DB, id);
        if (old && old.code !== code)
          throw new Error("Сначала покиньте текущий стол");
        const { game } = await mutate(
          env.DB,
          code,
          (g) => {
            if (g.mode === "training")
              throw new Error("Этот стол закрыт. Тренировка отключена");
            syncProfile(joinGame(g, id, playerName, now));
          },
          now,
        );
        await remember(env.DB, id, code, now);
        return json(publicView(game, id, env, now));
      }
      if (path.startsWith("/api/narration/") && req.method === "GET") {
        return narrationAudio(
          env,
          path.slice("/api/narration/".length),
          url.origin,
        );
      }
      if (path === "/api/voice/status" && req.method === "GET") {
        try {
          await checkService(env);
          return json({ connected: true });
        } catch (error) {
          return json({ connected: false, error: error.message }, 503);
        }
      }
      const match = path.match(
        /^\/api\/rooms\/([A-Z2-9]{6})(?:\/(action|voice))?$/,
      );
      if (!match) return json({ error: "Страница не найдена" }, 404);
      const [, code, operation] = match;
      const existing = await load(env.DB, code);
      if (existing.game.mode === "training")
        return json(
          { error: "Тренировка отключена. Вернитесь на главную." },
          410,
        );
      if (data.type === "training_next")
        return json({ error: "Действие недоступно" }, 400);
      if (
        req.method === "POST" &&
        operation === "action" &&
        ["ready", "start"].includes(data.type)
      ) {
        const actor = existing.game.players.find(
          (p) => p.accountId === id && !p.pendingLeave,
        );
        if (!actor) throw new Error("Вы не за столом");
        if (data.type === "start" || !actor.ready) {
          try {
            await checkService(env);
          } catch (error) {
            return json({ error: error.message }, 503);
          }
        }
      }
      if (operation === "voice" && req.method === "POST") {
        if (!configured(env))
          return json({ error: "Голосовой сервис ещё не подключён" }, 503);
        const { game, before } = await mutate(
          env.DB,
          code,
          (g) => {
            const p = g.players.find((p) => p.accountId === id);
            if (!p) throw new Error("Вы не за столом");
            syncProfile(p);
            p.lastSeen = now;
            tick(g, now);
          },
          now,
        );
        closePrevious(before, game, env, ctx);
        const p = game.players.find((p) => p.accountId === id),
          access = voiceAccess(game, p);
        const rooms = await Promise.all(
          access.rooms.map(async (room) => ({
            ...room,
            token: await token(env, p.id, p.name, {
              roomJoin: true,
              room: room.name,
              canPublish: room.publish,
              canSubscribe: true,
              canPublishData: false,
              ...(room.publish ? { canPublishSources: ["microphone"] } : {}),
            }),
          })),
        );
        return json({ url: env.LIVEKIT_URL, phaseSeq: game.phaseSeq, rooms });
      }
      if (
        req.method === "GET" ||
        (req.method === "POST" && operation === "action")
      ) {
        const { game, before } = await mutate(
          env.DB,
          code,
          (g) => {
            const p = g.players.find((p) => p.accountId === id);
            if (!p) {
              if (data.type === "leave") return;
              throw new Error("Вы не за столом");
            }
            // Tick before heartbeat: reconnecting after the grace period cannot revive a player.
            tick(g, now);
            syncProfile(p);
            p.lastSeen = now;
            if (!p.alive && !p.pendingLeave) p.departed = false;
            if (req.method === "POST") {
              // A room closes on every phase change. Its late disconnect event must not pause the next phase.
              if (
                ["voice_ok", "voice_error"].includes(data.type) &&
                data.voicePhaseSeq !== g.phaseSeq
              )
                return;
              command(g, id, data, now);
            }
          },
          now,
        );
        closePrevious(before, game, env, ctx);
        if (data.type === "leave") {
          await env.DB.prepare("DELETE FROM members WHERE account=? AND code=?")
            .bind(id, code)
            .run();
          return json({ left: true });
        }
        return json(publicView(game, id, env, now));
      }
      return json({ error: "Действие недоступно" }, 405);
    } catch (error) {
      if (error instanceof IdentityError) return json({ error: error.message }, error.status);
      console.error("Game request", error.message);
      return json({ error: error.message || "Не удалось обновить стол" }, 400);
    }
  },
};
